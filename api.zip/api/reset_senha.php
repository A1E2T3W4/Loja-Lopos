<?php
require_once 'config.php';

header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit(); }

$input  = json_decode(file_get_contents('php://input'), true) ?? [];
$action = $input['action'] ?? '';

/* ── PASSO 1: GERAR CÓDIGO (Sem expor o valor na API) ── */
if ($action === 'enviar') {
    $email = trim($input['email'] ?? '');

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(["success" => false, "message" => "E-mail inválido."]);
        exit();
    }

    $stmt = $pdo->prepare("SELECT id_cliente, nome, google_account, senha_manual FROM clientes WHERE email = :email LIMIT 1");
    $stmt->execute([':email' => $email]);
    $cliente = $stmt->fetch(PDO::FETCH_ASSOC);

    // Mesmo se o e-mail não existir, retornamos 'true' para evitar ataques de enumeração de utilizadores
    if (!$cliente) {
        echo json_encode(["success" => true, "message" => "Se o e-mail existir, um código foi enviado."]);
        exit();
    }

    if ($cliente['google_account'] == 1 && $cliente['senha_manual'] == 0) {
        echo json_encode(["success" => false, "message" => "Conta autenticada via Google. Redefinição não permitida."]);
        exit();
    }

    $pdo->prepare("DELETE FROM codigos_verificacao WHERE email = :email AND tipo = 'reset'")->execute([':email' => $email]);

    $codigo = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    $expira = date('Y-m-d H:i:s', strtotime('+15 minutes'));

    $pdo->prepare("INSERT INTO codigos_verificacao (email, codigo, tipo, usado, expira_em, criado_em) VALUES (?, ?, 'reset', 0, ?, NOW())")
        ->execute([$email, $codigo, $expira]);

    // O FRONT-END recebe apenas a confirmação. O e-mail deve ser enviado via API de e-mail (ex: EmailJS)
    echo json_encode([
        "success" => true, 
        "message" => "Código gerado.",
        "nome"    => $cliente['nome'] // Apenas o nome é seguro enviar
    ]);
    exit();
}

/* ── PASSO 2: VERIFICAR CÓDIGO ── */
if ($action === 'verificar') {
    $email  = trim($input['email'] ?? '');
    $codigo = trim($input['codigo'] ?? '');

    $stmt = $pdo->prepare("SELECT id FROM codigos_verificacao WHERE email = ? AND codigo = ? AND tipo = 'reset' AND usado = 0 AND expira_em > NOW()");
    $stmt->execute([$email, $codigo]);
    
    if (!$stmt->fetch()) {
        echo json_encode(["success" => false, "message" => "Código inválido ou expirado."]);
        exit();
    }
    echo json_encode(["success" => true, "message" => "Código validado."]);
    exit();
}

/* ── PASSO 3: REDEFINIR SENHA ── */
if ($action === 'redefinir') {
    $email      = trim($input['email'] ?? '');
    $codigo     = trim($input['codigo'] ?? '');
    $novaSenha  = $input['nova_senha'] ?? '';

    if (strlen($novaSenha) < 8) {
        echo json_encode(["success" => false, "message" => "Senha muito curta."]);
        exit();
    }

    $stmt = $pdo->prepare("SELECT id FROM codigos_verificacao WHERE email = ? AND codigo = ? AND tipo = 'reset' AND usado = 0 AND expira_em > NOW()");
    $stmt->execute([$email, $codigo]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        echo json_encode(["success" => false, "message" => "Sessão inválida."]);
        exit();
    }

    $pdo->prepare("UPDATE clientes SET senha = ?, senha_manual = 1 WHERE email = ?")
        ->execute([password_hash($novaSenha, PASSWORD_BCRYPT), $email]);

    $pdo->prepare("UPDATE codigos_verificacao SET usado = 1 WHERE id = ?")->execute([$row['id']]);

    echo json_encode(["success" => true, "message" => "Senha atualizada com sucesso."]);
    exit();
}

echo json_encode(["success" => false, "message" => "Ação inválida."]);