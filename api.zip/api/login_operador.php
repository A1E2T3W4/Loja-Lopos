<?php
// Inclui a conexão de produção e as definições unificadas de CORS
require_once 'config.php';

// Define o tipo de conteúdo da resposta padrão da API
header("Content-Type: application/json; charset=UTF-8");

$method = $_SERVER['REQUEST_METHOD'];

// Captura de metadados do cabeçalho da requisição para auditoria de segurança
$ip         = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '';
$user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';

/* ══════════════════════════════════════════════════════════════
    FUNÇÕES AUXILIARES / HELPERS
══════════════════════════════════════════════════════════════ */

// Sistema de logs assíncrono para auditoria de segurança no LOPOS
function registarLogin(
    PDO $pdo, ?int $id_usuario, string $user,
    string $nome, string $email, string $tipo,
    string $ip, string $user_agent,
    bool $sucesso, string $motivo = ''
): void {
    try {
        $pdo->prepare("
            INSERT INTO login_logs
                (id_usuario, user, nome, email, tipo, ip, user_agent, sucesso, motivo, data_log)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ")->execute([
            $id_usuario, $user, $nome, $email, $tipo,
            $ip, $user_agent, $sucesso ? 1 : 0, $motivo
        ]);
    } catch (Exception $e) { 
        // Supressão silenciosa para evitar travar o fluxo principal caso a tabela de logs falhe
    }
}

// Normaliza o nível de privilégio para os moldes aceites pelo backoffice
function normalizarTipo(string $tipo): string {
    $t = strtolower(trim($tipo));
    if ($t === 'gerente') return 'gerente';
    if ($t === 'admin')   return 'admin';
    return 'operador';
}

/* ══════════════════════════════════════════════════════════════
    POST — Processamento de Login e Criação de Contas
══════════════════════════════════════════════════════════════ */
if ($method === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true) ?? [];
    $acao = trim($data['acao'] ?? 'login');

    // ── Sub-módulo: Autenticação Baseada em Credenciais ──
    if ($acao === 'login') {
        $user  = trim($data['user']  ?? '');
        $senha = trim($data['senha'] ?? '');

        if (!$user || !$senha) {
            echo json_encode(["success" => false, "message" => "Utilizador e senha são obrigatórios."]);
            exit();
        }

        try {
            $stmt = $pdo->prepare("
                SELECT id_usuario, nome, user, email, senha, tipo,
                       ativo, super_admin, foto, ultimo_login
                FROM usuarios
                WHERE user = :u1 OR email = :u2 OR nome = :u3
                LIMIT 1
            ");
            $stmt->execute([':u1' => $user, ':u2' => $user, ':u3' => $user]);
            $operador = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$operador) {
                registarLogin($pdo, null, $user, '', '', '', $ip, $user_agent, false, 'Utilizador não encontrado');
                echo json_encode(["success" => false, "message" => "Utilizador não encontrado no sistema."]);
                exit();
            }

            if (!$operador['ativo']) {
                registarLogin($pdo, (int)$operador['id_usuario'], $user, $operador['nome'], $operador['email'], $operador['tipo'], $ip, $user_agent, false, 'Conta inactiva');
                echo json_encode(["success" => false, "message" => "Conta inactiva. Contacte o administrador do sistema."]);
                exit();
            }

            // Suporta nativamente encriptação por password_hash e fallback simples para migrações primárias
            $senhaOk = password_verify($senha, $operador['senha']) || ($senha === $operador['senha']);
            if (!$senhaOk) {
                registarLogin($pdo, (int)$operador['id_usuario'], $user, $operador['nome'], $operador['email'], $operador['tipo'], $ip, $user_agent, false, 'Senha incorrecta');
                echo json_encode(["success" => false, "message" => "Senha incorrecta."]);
                exit();
            }

            $tipoNorm = normalizarTipo($operador['tipo']);
            $tiposPermitidos = ['admin', 'gerente', 'operador'];

            if (!in_array($tipoNorm, $tiposPermitidos)) {
                registarLogin($pdo, (int)$operador['id_usuario'], $user, $operador['nome'], $operador['email'], $operador['tipo'], $ip, $user_agent, false, "Nível de acesso inválido: {$operador['tipo']}");
                echo json_encode([
                    "success" => false,
                    "message" => "Acesso negado. Perfil de utilizador sem privilégios comerciais mapeados.",
                    "tipo"    => $operador['tipo'],
                ]);
                exit();
            }

            // Registo de auditoria bem-sucedido e atualização do timestamp
            registarLogin($pdo, (int)$operador['id_usuario'], $user, $operador['nome'], $operador['email'], $operador['tipo'], $ip, $user_agent, true, 'Login efetuado com sucesso');
            $pdo->prepare("UPDATE usuarios SET ultimo_login = NOW() WHERE id_usuario = ?")->execute([$operador['id_usuario']]);

            // Serialização segura do BLOB de imagem para Base64 consumível no Frontend
            $fotoBase64 = null;
            if (!empty($operador['foto'])) {
                $fotoBase64 = "data:image/jpeg;base64," . base64_encode($operador['foto']);
            }

            // Purga campos sensíveis do payload de resposta por razões de arquitetura e segurança
            unset($operador['senha'], $operador['foto']);
            $operador['id_usuario']  = (int)$operador['id_usuario'];
            $operador['super_admin'] = (bool)$operador['super_admin'];
            $operador['ativo']       = (bool)$operador['ativo'];
            $operador['foto_url']    = $fotoBase64;
            $operador['tipo_norm']   = $tipoNorm;

            echo json_encode(["success" => true, "operador" => $operador]);

        } catch (Exception $e) {
            echo json_encode(["success" => false, "message" => "Erro no processo de login: " . $e->getMessage()]);
        }
        exit();
    }

    // ── Sub-módulo: Atualização de Perfil (Self-Service) ──
    if ($acao === 'actualizar_perfil') {
        $id    = intval($data['id_usuario'] ?? 0);
        $nome  = trim($data['nome']  ?? '');
        $email = trim($data['email'] ?? '');
        $user  = trim($data['user']  ?? '');
        $senha = trim($data['senha'] ?? '');
        $foto  = $data['foto_base64'] ?? null;

        if (!$id) {
            echo json_encode(["success" => false, "message" => "ID do utilizador em falta."]);
            exit();
        }

        try {
            $sets = []; $params = [];
            if ($nome)  { $sets[] = "nome=?";  $params[] = $nome;  }
            if ($email) { $sets[] = "email=?"; $params[] = $email; }
            if ($user)  { $sets[] = "user=?";  $params[] = $user;  }
            if ($senha && strlen($senha) >= 6) {
                $sets[] = "senha=?";
                $params[] = password_hash($senha, PASSWORD_DEFAULT);
            }
            if ($foto) {
                $fotoData = preg_replace('#^data:image/\w+;base64,#', '', $foto);
                $sets[] = "foto=?";
                $params[] = base64_decode($fotoData);
            }

            if (empty($sets)) {
                echo json_encode(["success" => false, "message" => "Nenhum campo foi modificado."]);
                exit();
            }

            $params[] = $id;
            $pdo->prepare("UPDATE usuarios SET " . implode(",", $sets) . " WHERE id_usuario=?")->execute($params);

            // Resgata o registo limpo e atualizado para re-injetar no State da aplicação cliente
            $q = $pdo->prepare("SELECT id_usuario, nome, user, email, tipo, super_admin, foto FROM usuarios WHERE id_usuario=?");
            $q->execute([$id]);
            $op = $q->fetch(PDO::FETCH_ASSOC);

            $fotoBase64 = null;
            if (!empty($op['foto'])) $fotoBase64 = "data:image/jpeg;base64," . base64_encode($op['foto']);
            
            unset($op['foto']);
            $op['foto_url']    = (string)$fotoBase64;
            $op['id_usuario']  = (int)$op['id_usuario'];
            $op['super_admin'] = (bool)$op['super_admin'];
            $op['tipo_norm']   = normalizarTipo($op['tipo']);

            echo json_encode(["success" => true, "operador" => $op]);

        } catch (Exception $e) {
            echo json_encode(["success" => false, "message" => "Erro ao atualizar dados cadastrais: " . $e->getMessage()]);
        }
        exit();
    }

    // ── Sub-módulo: Criação de Contas Extra (Painel Administrativo) ──
    if ($acao === 'criar_usuario') {
        $sid = intval($data['solicitante_id'] ?? 0);

        // Validação de permissões rígidas baseadas no solicitante ativo
        $qsa = $pdo->prepare("SELECT super_admin, tipo FROM usuarios WHERE id_usuario=? AND ativo=1");
        $qsa->execute([$sid]);
        $sa = $qsa->fetch(PDO::FETCH_ASSOC);

        $temPermissao = $sa && ($sa['super_admin'] || normalizarTipo($sa['tipo']) === 'admin');

        if (!$temPermissao) {
            echo json_encode(["success" => false, "message" => "Acesso negado. Apenas administradores podem criar utilizadores."]);
            exit();
        }

        $nome  = trim($data['nome']  ?? '');
        $user  = trim($data['user']  ?? '');
        $email = trim($data['email'] ?? '');
        $senha = trim($data['senha'] ?? '');
        $tipo  = trim($data['tipo']  ?? 'operador');

        if (!$nome || !$user || strlen($senha) < 4) {
            echo json_encode(["success" => false, "message" => "Campos obrigatórios em falta. Senha mínima de 4 caracteres."]);
            exit();
        }

        $tipoNorm = normalizarTipo($tipo);
        $tipoGuardar = match($tipoNorm) {
            'admin'   => 'admin',
            'gerente' => 'gerente',
            default   => 'operador',
        };

        try {
            // Verificação de concorrência e unicidade de logins
            $qdup = $pdo->prepare("SELECT id_usuario FROM usuarios WHERE user=? OR email=?");
            $qdup->execute([$user, $email]);
            if ($qdup->fetch()) {
                echo json_encode(["success" => false, "message" => "O nome de utilizador ou e-mail já se encontra registado."]);
                exit();
            }

            $pdo->prepare("
                INSERT INTO usuarios (nome, user, email, senha, tipo, ativo, super_admin)
                VALUES (?, ?, ?, ?, ?, 1, 0)
            ")->execute([$nome, $user, $email, password_hash($senha, PASSWORD_DEFAULT), $tipoGuardar]);

            echo json_encode([
                "success" => true,
                "id"      => (int)$pdo->lastInsertId(),
                "tipo"    => $tipoGuardar,
                "message" => "Utilizador '$nome' registado com sucesso sob a função de $tipoGuardar.",
            ]);

        } catch (Exception $e) {
            echo json_encode(["success" => false, "message" => "Erro ao criar utilizador: " . $e->getMessage()]);
        }
        exit();
    }

    echo json_encode(["success" => false, "message" => "Ação administrativa desconhecida."]);
    exit();
}

/* ══════════════════════════════════════════════════════════════
    GET — Listagem Geral de Utilizadores Cadastrados
══════════════════════════════════════════════════════════════ */
if ($method === 'GET') {
    $sid = intval($_GET['solicitante_id'] ?? 0);

    $qsa = $pdo->prepare("SELECT super_admin, tipo FROM usuarios WHERE id_usuario=? AND ativo=1");
    $qsa->execute([$sid]);
    $sa = $qsa->fetch(PDO::FETCH_ASSOC);

    $temPermissao = $sa && ($sa['super_admin'] || normalizarTipo($sa['tipo']) === 'admin');

    if (!$temPermissao) {
        echo json_encode(["success" => false, "message" => "Acesso negado. Permissão insuficiente para listagem corporativa."]);
        exit();
    }

    try {
        $q = $pdo->query("
            SELECT id_usuario, nome, user, email, tipo, ativo, super_admin, ultimo_login, criado_em
            FROM usuarios
            ORDER BY criado_em DESC
        ");
        $lista = $q->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($lista as &$u) {
            $u['id_usuario']  = (int)$u['id_usuario'];
            $u['super_admin'] = (bool)$u['super_admin'];
            $u['ativo']       = (bool)$u['ativo'];
            $u['tipo_norm']   = normalizarTipo($u['tipo']);
        }
        
        echo json_encode(["success" => true, "data" => $lista]);

    } catch (Exception $e) {
        echo json_encode(["success" => false, "message" => "Erro ao compilar lista de colaboradores: " . $e->getMessage()]);
    }
    exit();
}

/* ══════════════════════════════════════════════════════════════
    PUT — Gestão de Status e Perfis (Bloqueio/Funções)
══════════════════════════════════════════════════════════════ */
if ($method === 'PUT') {
    $data = json_decode(file_get_contents("php://input"), true) ?? [];
    $sid  = intval($data['solicitante_id'] ?? 0);
    $alvo = intval($data['id_usuario']     ?? 0);

    $qsa = $pdo->prepare("SELECT super_admin, tipo FROM usuarios WHERE id_usuario=? AND ativo=1");
    $qsa->execute([$sid]);
    $sa = $qsa->fetch(PDO::FETCH_ASSOC);

    $temPermissao = $sa && ($sa['super_admin'] || normalizarTipo($sa['tipo']) === 'admin');

    if (!$temPermissao) {
        echo json_encode(["success" => false, "message" => "Acesso negado. Sem privilégios executivos."]);
        exit();
    }
    
    if ($alvo === $sid) {
        echo json_encode(["success" => false, "message" => "Modificação restrita. Não pode alterar o seu próprio estatuto neste painel."]);
        exit();
    }

    try {
        $sets = []; $params = [];
        if (isset($data['ativo'])) {
            $sets[]   = "ativo=?";
            $params[] = $data['ativo'] ? 1 : 0;
        }
        if (isset($data['tipo'])) {
            $tipoGuardar = match(normalizarTipo($data['tipo'])) {
                'admin'   => 'admin',
                'gerente' => 'gerente',
                default   => 'operador',
            };
            $sets[]   = "tipo=?";
            $params[] = $tipoGuardar;
        }

        if (empty($sets)) {
            echo json_encode(["success" => false, "message" => "Nenhuma modificação estrutural foi enviada."]);
            exit();
        }

        $params[] = $alvo;
        $pdo->prepare("UPDATE usuarios SET " . implode(",", $sets) . " WHERE id_usuario=?")->execute($params);
        echo json_encode(["success" => true, "message" => "Dados corporativos do utilizador modificados com sucesso."]);

    } catch (Exception $e) {
        echo json_encode(["success" => false, "message" => "Erro ao aplicar alterações no utilizador: " . $e->getMessage()]);
    }
    exit();
}

/* ══════════════════════════════════════════════════════════════
    DELETE — Exclusão Definitiva de Colaborador
══════════════════════════════════════════════════════════════ */
if ($method === 'DELETE') {
    $sid  = intval($_GET['solicitante_id'] ?? 0);
    $alvo = intval($_GET['id_usuario']     ?? 0);

    $qsa = $pdo->prepare("SELECT super_admin, tipo FROM usuarios WHERE id_usuario=? AND ativo=1");
    $qsa->execute([$sid]);
    $sa = $qsa->fetch(PDO::FETCH_ASSOC);

    $temPermissao = $sa && ($sa['super_admin'] || normalizarTipo($sa['tipo']) === 'admin');

    if (!$temPermissao) {
        echo json_encode(["success" => false, "message" => "Acesso negado. Privilégios insuficientes."]);
        exit();
    }
    if ($alvo === $sid) {
        echo json_encode(["success" => false, "message" => "Operação inválida. Não é permitido auto-eliminar a conta em execução."]);
        exit();
    }

    try {
        $pdo->prepare("DELETE FROM usuarios WHERE id_usuario=?")->execute([$alvo]);
        echo json_encode(["success" => true, "message" => "Utilizador removido do ecossistema comercial com sucesso."]);

    } catch (Exception $e) {
        echo json_encode(["success" => false, "message" => "Erro crítico ao eliminar colaborador: " . $e->getMessage()]);
    }
    exit();
}

// Resposta padrão para métodos ou verbos HTTP não suportados de forma direta
http_response_code(405);
echo json_encode(["success" => false, "message" => "Método não suportado pelo motor de autenticação."]);
?>