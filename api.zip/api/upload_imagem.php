<?php
require_once 'config.php';
header("Content-Type: application/json; charset=UTF-8");

// Pasta de destino no InfinityFree
$uploadDir = __DIR__ . "/../uploads/produtos/";
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

if ($_SERVER["REQUEST_METHOD"] !== "POST" || !isset($_FILES["imagem"])) {
    echo json_encode(["success" => false, "message" => "Método inválido ou sem ficheiro."]);
    exit;
}

$file = $_FILES["imagem"];
if ($file["error"] !== UPLOAD_ERR_OK) {
    echo json_encode(["success" => false, "message" => "Erro de upload: código " . $file["error"]]);
    exit;
}

// Verificação MIME
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime  = finfo_file($finfo, $file["tmp_name"]);
finfo_close($finfo);

if (!in_array($mime, ["image/jpeg", "image/png", "image/webp", "image/gif"])) {
    echo json_encode(["success" => false, "message" => "Tipo de ficheiro não permitido."]);
    exit;
}

// Limite 5MB
if ($file["size"] > 5 * 1024 * 1024) {
    echo json_encode(["success" => false, "message" => "Ficheiro excede 5MB."]);
    exit;
}

$ext      = strtolower(pathinfo($file["name"], PATHINFO_EXTENSION));
$safeName = bin2hex(random_bytes(16)) . "." . $ext;
$destino  = $uploadDir . $safeName;

// URL base corrigida para o teu domínio InfinityFree
$baseUrl  = "https://lojalopos.infinityfreeapp.com/uploads/produtos/";

if (move_uploaded_file($file["tmp_name"], $destino)) {
    echo json_encode([
        "success" => true,
        "url"     => $baseUrl . $safeName,
        "nome"    => $safeName
    ]);
} else {
    echo json_encode(["success" => false, "message" => "Falha ao gravar em disco. Verifique permissões da pasta."]);
}