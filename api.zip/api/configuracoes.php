<?php
// Inclui a conexão de produção e os cabeçalhos CORS globais
require_once 'config.php';

// Define o tipo de conteúdo como JSON em UTF-8
header("Content-Type: application/json; charset=UTF-8");

$method = $_SERVER['REQUEST_METHOD'];

// ── GET — Recuperar Configurações da Loja ───────────────────────
if ($method === 'GET') {
    try {
        $stmt = $pdo->query("SELECT * FROM configuracao_loja WHERE id = 1 LIMIT 1");
        $row  = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$row) {
            $pdo->exec("INSERT INTO configuracao_loja (id, nome_loja) VALUES (1, 'LOPOS TEC')");
            $row = ['id' => 1, 'nome_loja' => 'LOPOS TEC'];
        }

        // Garante que todos os campos estruturais existem na resposta do JSON
        $defaults = [
            'nif'             => '',
            'telefone'        => '',
            'email'           => '',
            'endereco'        => '',
            'url_site'        => '',
            'api_base_url'    => '',
            'emailjs_service' => '',
            'emailjs_key'     => '',
            'iva'             => 0,
            'taxa_km'         => 0,
            'compras_vip'     => 0,
        ];
        foreach ($defaults as $campo => $padrao) {
            if (!array_key_exists($campo, $row)) {
                $row[$campo] = $padrao;
            }
        }

        echo json_encode(["success" => true, "data" => $row]);

    } catch (Exception $e) {
        echo json_encode(["success" => false, "message" => "Erro ao ler dados: " . $e->getMessage()]);
    }
    exit();
}

// ── PUT — Atualizar Configurações Dinamicamente ────────────────
if ($method === 'PUT') {
    $data = json_decode(file_get_contents("php://input"), true) ?? [];

    if (empty($data)) {
        echo json_encode(["success" => false, "message" => "Dados inválidos ou vazios."]);
        exit();
    }

    try {
        // Mapeamento de segurança contra injeção de colunas inválidas
        $camposPermitidos = [
            'nome_loja', 'nif', 'telefone', 'email', 'endereco',
            'url_site', 'api_base_url', 'emailjs_service', 'emailjs_key',
            'iva', 'taxa_km', 'compras_vip',
        ];

        // Verifica colunas reais que existem na tabela da Base de Dados
        $stmtCols  = $pdo->query("SHOW COLUMNS FROM configuracao_loja");
        $colunasBD = array_column($stmtCols->fetchAll(PDO::FETCH_ASSOC), 'Field');

        $sets   = [];
        $params = []; // Named parameters para evitar o erro HY093

        foreach ($camposPermitidos as $campo) {
            if (in_array($campo, $colunasBD) && array_key_exists($campo, $data)) {
                $sets[]            = "$campo = :$campo";
                $params[":$campo"] = $data[$campo];
            }
        }

        if (empty($sets)) {
            echo json_encode([
                "success"       => false,
                "message"       => "Nenhum campo válido enviado para actualizar.",
                "colunas_bd"    => $colunasBD,
                "data_recebida" => array_keys($data),
            ]);
            exit();
        }

        $params[':id'] = 1;
        $sql  = "UPDATE configuracao_loja SET " . implode(", ", $sets) . " WHERE id = :id";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        // Devolve os dados atualizados em tempo real para o estado do React
        $stmt2 = $pdo->query("SELECT * FROM configuracao_loja WHERE id = 1 LIMIT 1");
        $row   = $stmt2->fetch(PDO::FETCH_ASSOC);

        echo json_encode([
            "success"       => true,
            "message"       => "Configurações guardadas com sucesso.",
            "data"          => $row,
            "campos_salvos" => count($sets),
        ]);

    } catch (Exception $e) {
        echo json_encode([
            "success" => false,
            "message" => "Erro ao guardar configurações: " . $e->getMessage(),
            "code"    => $e->getCode(),
        ]);
    }
    exit();
}

// Resposta para métodos não suportados
http_response_code(405);
echo json_encode(["success" => false, "message" => "Método não suportado."]);
?>