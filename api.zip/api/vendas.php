<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
date_default_timezone_set('Africa/Luanda');

require_once "config.php";

try {
    // 1. Otimização: Obter totais de hoje e ontem numa única consulta agrupada
    $q = $pdo->query("
        SELECT 
            SUM(CASE WHEN DATE(data_movimento) = CURDATE() THEN valor ELSE 0 END) as hoje,
            SUM(CASE WHEN DATE(data_movimento) = CURDATE() - INTERVAL 1 DAY THEN valor ELSE 0 END) as ontem
        FROM financeiro 
        WHERE tipo = 'ENTRADA' AND status = 'CONFIRMADO'
    ");
    $totais = $q->fetch(PDO::FETCH_ASSOC);

    // 2. Otimização: Receitas Mensais em uma única chamada
    $q = $pdo->query("
        SELECT 
            SUM(CASE WHEN MONTH(data_movimento) = MONTH(CURDATE()) AND YEAR(data_movimento) = YEAR(CURDATE()) THEN valor ELSE 0 END) as atual,
            SUM(CASE WHEN MONTH(data_movimento) = MONTH(CURDATE() - INTERVAL 1 MONTH) AND YEAR(data_movimento) = YEAR(CURDATE() - INTERVAL 1 MONTH) THEN valor ELSE 0 END) as anterior
        FROM financeiro 
        WHERE tipo = 'ENTRADA' AND status = 'CONFIRMADO'
    ");
    $meses = $q->fetch(PDO::FETCH_ASSOC);

    // 3. Gráfico dos últimos 7 dias (SQL puro simplificado)
    $q = $pdo->query("
        SELECT DATE(data_movimento) as dia, SUM(valor) as total
        FROM financeiro
        WHERE tipo = 'ENTRADA' AND status = 'CONFIRMADO'
        AND data_movimento >= CURDATE() - INTERVAL 6 DAY
        GROUP BY DATE(data_movimento)
        ORDER BY dia ASC
    ");
    $rows = $q->fetchAll(PDO::FETCH_ASSOC);

    // Preenchimento de lacunas para garantir 7 posições exatas no gráfico
    $ultimos7 = [];
    for ($i = 6; $i >= 0; $i--) {
        $data = date("Y-m-d", strtotime("-$i days"));
        $val = 0;
        foreach ($rows as $r) {
            if ($r['dia'] === $data) {
                $val = (float)$r['total'];
                break;
            }
        }
        $ultimos7[] = $val;
    }

    echo json_encode([
        "success"         => true,
        "total"           => (float)($totais['hoje'] ?? 0),
        "total_ontem"     => (float)($totais['ontem'] ?? 0),
        "receita_mes"     => (float)($meses['atual'] ?? 0),
        "receita_mes_ant" => (float)($meses['anterior'] ?? 0),
        "ultimos7"        => $ultimos7
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => "Erro ao processar métricas financeiras."]);
}