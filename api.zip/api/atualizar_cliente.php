<?php
// Inclui a conexão de produção e os cabeçalhos CORS centrais
require_once 'config.php';

// Define o tipo de conteúdo como JSON em UTF-8
header("Content-Type: application/json; charset=UTF-8");

// Garante que apenas requisições POST são processadas
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); // Código 405: Método não suportado
    echo json_encode(["success" => false, "message" => "Método não suportado."]);
    exit;
}

try {
    // Recebe e decodifica o input JSON vindo do teu React
    $d          = json_decode(file_get_contents("php://input"), true);
    $id_cliente = isset($d['id_cliente']) ? intval($d['id_cliente']) : 0;

    if (!$id_cliente) {
        echo json_encode(["success" => false, "message" => "id_cliente obrigatório."]);
        exit;
    }

    $sets   = [];
    $params = [];

    /* Nome */
    if (!empty(trim($d['nome'] ?? ''))) {
        $sets[]   = "nome = ?";
        $params[] = trim($d['nome']);
    }

    /* Telefone (pode ser vazio para limpar) */
    if (isset($d['telefone'])) {
        $sets[]   = "telefone = ?";
        $params[] = trim($d['telefone']);
    }

    /* Senha — só actualiza se enviada e válida com pelo menos 8 caracteres */
    if (!empty(trim($d['senha'] ?? ''))) {
        if (strlen(trim($d['senha'])) < 8) {
            echo json_encode(["success" => false, "message" => "A senha deve ter pelo menos 8 caracteres."]);
            exit;
        }
        $sets[]   = "senha = ?";
        $params[] = password_hash(trim($d['senha']), PASSWORD_BCRYPT);
        $sets[]   = "senha_manual = 1";
    }

    // Se nenhum campo válido foi enviado no JSON
    if (empty($sets)) {
        echo json_encode(["success" => false, "message" => "Nenhum dado para actualizar."]);
        exit;
    }

    // Adiciona o ID do cliente como o último parâmetro do WHERE
    $params[] = $id_cliente;

    // Monta e executa a Query Dinâmica de Update
    $sql = "UPDATE clientes SET " . implode(", ", $sets) . " WHERE id_cliente = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    /* Devolve os dados actualizados para o frontend atualizar o localStorage instantaneamente */
    $qc = $pdo->prepare("
        SELECT id_cliente, nome, email, telefone, foto_url,
               saldo_bonus, compras_realizadas, cliente_verificado
        FROM clientes WHERE id_cliente = ?
    ");
    $qc->execute([$id_cliente]);
    $cliente = $qc->fetch(PDO::FETCH_ASSOC);

    echo json_encode([
        "success" => true,
        "message" => "Dados actualizados com sucesso.",
        "cliente" => $cliente,
    ]);

} catch (Exception $e) {
    // Retorna o erro capturado em formato JSON legível pelo React
    echo json_encode(["success" => false, "message" => "Erro no servidor: " . $e->getMessage()]);
}
?>