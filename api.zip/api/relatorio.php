<?php
// Inclui a conexão configurada
require_once "config.php";

// Definições de cabeçalho e segurança
header("Content-Type: application/json; charset=UTF-8");
date_default_timezone_set('Africa/Luanda');

// Validação estrita de método
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(["success" => false, "message" => "Método não permitido."]);
    exit;
}

/* ══════════════════════════════════════════════════════════════
    DEFINIÇÃO DE PERÍODO (Contexto Temporal)
══════════════════════════════════════════════════════════════ */
$periodo = strtolower(trim($_GET['periodo'] ?? 'mensal'));
$allowed = ['semanal', 'mensal', 'anual'];

if (!in_array($periodo, $allowed)) $periodo = 'mensal';

switch ($periodo) {
    case 'semanal':
        $inicio = date("Y-m-d", strtotime('monday this week'));
        $fim    = date("Y-m-d", strtotime('sunday this week'));
        $label  = "Semana " . date("W") . " (" . date("d/m", strtotime($inicio)) . " a " . date("d/m", strtotime($fim)) . ")";
        break;
    case 'anual':
        $inicio = date("Y-01-01");
        $fim    = date("Y-12-31");
        $label  = "Ano de " . date("Y");
        break;
    default:
        $inicio = date("Y-m-01");
        $fim    = date("Y-m-t");
        $meses  = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
        $label  = $meses[(int)date("m") - 1] . " de " . date("Y");
        break;
}

$fimInclusive = $fim . " 23:59:59";

try {
    /* ════════════════════════════════════════════════════════════
        EXECUÇÃO DE CONSULTAS (KPIs)
    ════════════════════════════════════════════════════════════ */

    // 1. Pedidos
    $qPedidos = $pdo->prepare("SELECT COUNT(*) as total, COUNT(CASE WHEN status='pendente' THEN 1 END) as pendentes, COUNT(CASE WHEN status='reservado' THEN 1 END) as reservados, COUNT(CASE WHEN status='enviado' THEN 1 END) as enviados, COUNT(CASE WHEN status='entregue' THEN 1 END) as entregues, COUNT(CASE WHEN status='cancelado' THEN 1 END) as cancelados, COALESCE(SUM(CASE WHEN status <> 'cancelado' THEN total END), 0) as receita_total FROM pedidos WHERE criado_em BETWEEN ? AND ?");
    $qPedidos->execute([$inicio, $fimInclusive]);
    $pedidos = $qPedidos->fetch(PDO::FETCH_ASSOC);

    // 2. Clientes e Verificação
    $qClientes = $pdo->prepare("SELECT COUNT(*) as novos, COUNT(CASE WHEN cliente_verificado = 1 THEN 1 END) as verificados_novos FROM clientes WHERE criado_em BETWEEN ? AND ?");
    $qClientes->execute([$inicio, $fimInclusive]);
    $clientesNovos = $qClientes->fetch(PDO::FETCH_ASSOC);

    // 3. Produtos e Stock
    $qProdutos = $pdo->prepare("SELECT COUNT(*) as criados, COUNT(CASE WHEN status = 'disponivel' THEN 1 END) as disponiveis, COUNT(CASE WHEN status = 'esgotado' THEN 1 END) as esgotados FROM produtos WHERE criado_em BETWEEN ? AND ?");
    $qProdutos->execute([$inicio, $fimInclusive]);
    $produtos = $qProdutos->fetch(PDO::FETCH_ASSOC);

    // 4. Financeiro
    $qFin = $pdo->prepare("SELECT COALESCE(SUM(CASE WHEN tipo = 'ENTRADA' AND status = 'CONFIRMADO' THEN valor END), 0) as entradas, COALESCE(SUM(CASE WHEN tipo = 'SAIDA' AND status = 'CONFIRMADO' THEN valor END), 0) as saidas FROM financeiro WHERE data_movimento BETWEEN ? AND ?");
    $qFin->execute([$inicio, $fimInclusive]);
    $fin = $qFin->fetch(PDO::FETCH_ASSOC);

    /* ════════════════════════════════════════════════════════════
        MONTAGEM DO PAYLOAD JSON
    ════════════════════════════════════════════════════════════ */
    echo json_encode([
        "success" => true,
        "label"   => $label,
        "pedidos" => [
            "total"         => (int)$pedidos['total'],
            "pendentes"     => (int)$pedidos['pendentes'],
            "receita_total" => (float)$pedidos['receita_total']
        ],
        "clientes" => [
            "novos"             => (int)$clientesNovos['novos'],
            "total_verificados" => (int)$pdo->query("SELECT COUNT(*) FROM clientes WHERE cliente_verificado = 1")->fetchColumn()
        ],
        "financeiro" => [
            "entradas" => (float)$fin['entradas'],
            "saidas"   => (float)$fin['saidas'],
            "saldo"    => (float)($fin['entradas'] - $fin['saidas'])
        ]
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => "Erro interno no processamento do dashboard."]);
}