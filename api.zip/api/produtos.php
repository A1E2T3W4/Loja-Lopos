<?php
// Inclui a conexão de produção e as diretivas unificadas de CORS
require_once "config.php";

// Garante que o retorno é interpretado estritamente como JSON estruturado
header("Content-Type: application/json; charset=UTF-8");

$method = $_SERVER["REQUEST_METHOD"];
$id     = isset($_GET["id"]) ? intval($_GET["id"]) : 0;

/* ══════════════════════════════════════════════════════════════
    HELPERS — Tratamento de Dados e Regras de Stock
══════════════════════════════════════════════════════════════ */

function montarImagens(array &$p): void {
    $imagens = [];
    foreach (["imagem_url", "img1", "img2", "img3", "img4", "img5"] as $campo) {
        if (!empty($p[$campo])) $imagens[] = $p[$campo];
        unset($p[$campo]);
    }
    if (!empty($p["imagens_extras"])) {
        $extras = json_decode($p["imagens_extras"], true);
        if (is_array($extras)) $imagens = array_merge($imagens, array_filter($extras));
    }
    unset($p["imagens_extras"]);
    $p["imagens"]    = array_values(array_unique($imagens));
    $p["imagem_url"] = $imagens[0] ?? "";
}

function calcularStatus(int $estoque, int $estoqueMinimo, string $statusActual): string {
    if ($statusActual === 'descontinuado') return 'descontinuado';
    return $estoque <= $estoqueMinimo ? 'esgotado' : 'disponivel';
}

/* ══════════════════════════════════════════════════════════════
    ROTAS E OPERAÇÕES DO CATÁLOGO
══════════════════════════════════════════════════════════════ */
try {

    /* ── MÉTODOS DE LEITURA (GET) ── */
    if ($method === "GET") {
        $categoria = $_GET["categoria"] ?? "";
        $busca     = $_GET["busca"]     ?? "";
        $soAtivos  = isset($_GET["loja"]);
        $ofertas   = isset($_GET["ofertas"]);

        $sql = "SELECT
                    id_produto, sku, nome, descricao, marca,
                    img1, img2, img3, img4, img5, 
                    preco, preco_antigo, custo,
                    estoque, estoque_minimo,
                    bonus_percentual, bonus_saldo,
                    ativo, status, categoria,
                    criado_em, atualizado_em
                FROM produtos WHERE 1=1";
        $params = [];

        if ($soAtivos) {
            $sql .= " AND ativo = 1 AND status = 'disponivel'";
        }
        if ($id)        { $sql .= " AND id_produto = ?"; $params[] = $id; }
        if ($categoria) { $sql .= " AND categoria = ?";  $params[] = $categoria; }
        if ($ofertas)   { $sql .= " AND bonus_percentual > 0 AND ativo = 1 AND status = 'disponivel'"; }
        if ($busca) {
            $sql .= " AND (nome LIKE ? OR descricao LIKE ? OR marca LIKE ?)";
            $like = "%$busca%";
            $params[] = $like; $params[] = $like; $params[] = $like;
        }
        $sql .= " ORDER BY id_produto DESC";

        $q = $pdo->prepare($sql);
        $q->execute($params);
        $rows = $q->fetchAll(PDO::FETCH_ASSOC);

        foreach ($rows as &$p) {
            montarImagens($p);
            
            // Casting explícito para garantir integridade tipada no React Native
            $p["id_produto"]       = (int)$p["id_produto"];
            $p["estoque"]          = (int)$p["estoque"];
            $p["estoque_minimo"]   = (int)$p["estoque_minimo"];
            $p["ativo"]            = (int)$p["ativo"];
            $p["preco"]            = (float)$p["preco"];
            $p["preco_antigo"]     = $p["preco_antigo"] !== null ? (float)$p["preco_antigo"] : null;
            $p["custo"]            = $p["custo"] !== null ? (float)$p["custo"] : null;
            $p["bonus_saldo"]      = (float)($p["bonus_saldo"] ?? 0);
            $p["bonus_percentual"] = (float)($p["bonus_percentual"] ?? 0);
            $p["status"]           = $p["status"] ?? "disponivel";

            $bp = $p["bonus_percentual"];
            $p["preco_com_desconto"] = $bp > 0 ? round($p["preco"] * (1 - $bp / 100), 2) : null;
            $p["tem_oferta"]    = $bp > 0;
            $p["esta_esgotado"] = $p["status"] === "esgotado";
        }
        unset($p);

        echo json_encode(["success" => true, "data" => $rows, "total" => count($rows)]);
        exit;
    }

    /* ── INSERÇÃO DE NOVOS PRODUTOS (POST) ── */
    if ($method === "POST") {
        $d = json_decode(file_get_contents("php://input"), true) ?? [];

        if (empty($d["nome"]) || !isset($d["preco"])) {
            echo json_encode(["success" => false, "message" => "Os campos nome e preço são obrigatórios."]);
            exit;
        }

        $imagens = $d["imagens"] ?? [];
        if (empty($imagens) && !empty($d["imagem_url"])) $imagens = [$d["imagem_url"]];
        $img1 = $imagens[0] ?? null; $img2 = $imagens[1] ?? null;
        $img3 = $imagens[2] ?? null; $img4 = $imagens[3] ?? null;
        $img5 = $imagens[4] ?? null;
        $extras = array_slice($imagens, 5);
        $imagens_extras = count($extras) ? json_encode($extras) : null;

        $estoque    = intval($d["estoque"] ?? 0);
        $estoqueMin = intval($d["estoque_minimo"] ?? 5);
        $status     = calcularStatus($estoque, $estoqueMin, 'disponivel');

        $preco            = floatval($d["preco"] ?? 0);
        $preco_antigo     = isset($d["preco_antigo"]) && $d["preco_antigo"] !== "" && $d["preco_antigo"] !== null ? floatval($d["preco_antigo"]) : null;
        $custo            = isset($d["custo"]) && $d["custo"] !== "" && $d["custo"] !== null ? floatval($d["custo"]) : null;
        $bonus_percentual = floatval($d["bonus_percentual"] ?? 0);
        $bonus_saldo      = floatval($d["bonus_saldo"] ?? 0);

        $q = $pdo->prepare("
            INSERT INTO produtos
              (nome, descricao, marca, preco, preco_antigo, custo,
               estoque, estoque_minimo,
               bonus_percentual, bonus_saldo,
               ativo, status, categoria,
               img1, img2, img3, img4, img5, imagens_extras)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        ");
        $q->execute([
            trim($d["nome"]),
            trim($d["descricao"]  ?? ""),
            trim($d["marca"]      ?? ""),
            $preco,
            $preco_antigo,
            $custo,
            $estoque,
            $estoqueMin,
            $bonus_percentual,
            $bonus_saldo,
            ($d["ativo"] ?? true) ? 1 : 0,
            $status,
            $d["categoria"] ?? "Computadores",
            $img1, $img2, $img3, $img4, $img5,
            $imagens_extras,
        ]);

        $novoId = (int)$pdo->lastInsertId();

        echo json_encode([
            "success"     => true,
            "id_produto"  => $novoId,
            "status"      => $status,
            "bonus_saldo" => $bonus_saldo,
            "message"     => $status === 'esgotado'
                ? "Produto indexado com aviso de ESGOTADO (stock menor ou igual ao de segurança)."
                : "Produto registado com sucesso no catálogo LOPOS.",
        ]);
        exit;
    }

    /* ── ALTERAÇÃO DE PRODUTOS (PUT) ── */
    if ($method === "PUT") {
        $d  = json_decode(file_get_contents("php://input"), true) ?? [];
        $id = intval($d["id_produto"] ?? $id);

        if (!$id) {
            echo json_encode(["success" => false, "message" => "Identificador id_produto em falta para atualização."]);
            exit;
        }

        $imagens = $d["imagens"] ?? [];
        if (empty($imagens) && !empty($d["imagem_url"])) $imagens = [$d["imagem_url"]];
        $img1 = $imagens[0] ?? null; $img2 = $imagens[1] ?? null;
        $img3 = $imagens[2] ?? null; $img4 = $imagens[3] ?? null;
        $img5 = $imagens[4] ?? null;
        $extras = array_slice($imagens, 5);
        $imagens_extras = count($extras) ? json_encode($extras) : null;

        $estoque      = intval($d["estoque"] ?? 0);
        $estoqueMin   = intval($d["estoque_minimo"] ?? 5);
        $statusManual = $d["status"] ?? null;
        $status       = ($statusManual === 'descontinuado')
            ? 'descontinuado'
            : calcularStatus($estoque, $estoqueMin, $statusManual ?? 'disponivel');

        $preco            = floatval($d["preco"] ?? 0);
        $preco_antigo     = isset($d["preco_antigo"]) && $d["preco_antigo"] !== "" && $d["preco_antigo"] !== null ? floatval($d["preco_antigo"]) : null;
        $custo            = isset($d["custo"]) && $d["custo"] !== "" && $d["custo"] !== null ? floatval($d["custo"]) : null;
        $bonus_percentual = floatval($d["bonus_percentual"] ?? 0);
        $bonus_saldo      = floatval($d["bonus_saldo"] ?? 0);

        $q = $pdo->prepare("
            UPDATE produtos SET
                nome              = ?,
                descricao         = ?,
                marca             = ?,
                preco             = ?,
                preco_antigo      = ?,
                custo             = ?,
                estoque           = ?,
                estoque_minimo    = ?,
                bonus_percentual  = ?,
                bonus_saldo       = ?,
                ativo             = ?,
                status            = ?,
                categoria         = ?,
                img1 = ?, img2 = ?, img3 = ?, img4 = ?, img5 = ?,
                imagens_extras    = ?
            WHERE id_produto = ?
        ");
        $q->execute([
            trim($d["nome"]),
            trim($d["descricao"]  ?? ""),
            trim($d["marca"]      ?? ""),
            $preco,
            $preco_antigo,
            $custo,
            $estoque,
            $estoqueMin,
            $bonus_percentual,
            $bonus_saldo,
            ($d["ativo"] ?? true) ? 1 : 0,
            $status,
            $d["categoria"] ?? "Computadores",
            $img1, $img2, $img3, $img4, $img5,
            $imagens_extras,
            $id,
        ]);

        echo json_encode([
            "success"     => true,
            "status"      => $status,
            "bonus_saldo" => $bonus_saldo,
            "message"     => match($status) {
                'esgotado'      => "Modificações guardadas. O stock atingiu o patamar mínimo e o item foi ocultado da montra.",
                'descontinuado' => "Produto alterado e definido como descontinuado.",
                default         => "Ficha de produto atualizada com sucesso.",
            },
        ]);
        exit;
    }

    /* ── REMOÇÃO PURA DE ITEM (DELETE) ── */
    if ($method === "DELETE") {
        $id = intval($_GET["id"] ?? 0);
        if (!$id) {
            $body = json_decode(file_get_contents("php://input"), true);
            $id   = intval($body["id_produto"] ?? $body["id"] ?? 0);
        }
        if (!$id) {
            echo json_encode(["success" => false, "message" => "Identificador id_produto não especificado para remoção."]);
            exit;
        }

        $check = $pdo->prepare("SELECT nome FROM produtos WHERE id_produto = ?");
        $check->execute([$id]);
        $produto = $check->fetch(PDO::FETCH_ASSOC);
        if (!$produto) {
            echo json_encode(["success" => false, "message" => "O artigo pretendido não existe na base de dados."]);
            exit;
        }

        // Limpeza em cascata preventiva para preservar chaves estrangeiras
        $pdo->prepare("DELETE FROM itens_pedido WHERE id_produto = ?")->execute([$id]);
        $pdo->prepare("DELETE FROM favoritos    WHERE id_produto = ?")->execute([$id]);
        $pdo->prepare("DELETE FROM produtos     WHERE id_produto = ?")->execute([$id]);

        echo json_encode([
            "success" => true,
            "message" => "O artigo \"{$produto['nome']}\" foi inteiramente expurgado do sistema.",
        ]);
        exit;
    }

} catch (Exception $e) {
    echo json_encode([
        "success" => false, 
        "message" => "Exceção disparada no barramento de catálogo: " . $e->getMessage()
    ]);
    exit;
}

// Fallback unificado para requisições inválidas fora dos métodos aceites
echo json_encode(["success" => false, "message" => "Interface de requisição HTTP não mapeada."]);
?>