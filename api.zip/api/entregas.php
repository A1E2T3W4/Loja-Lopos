<?php
// Inclui a conexão de produção corrigida e os cabeçalhos CORS globais
require_once 'config.php';

// Define o tipo de conteúdo como JSON em UTF-8
header("Content-Type: application/json; charset=UTF-8");

$method = $_SERVER['REQUEST_METHOD'];
$id     = isset($_GET['id']) ? intval($_GET['id']) : 0;

try {
    // ── GET — Listar Entregas (Filtros por Pedido ou Estafeta) ────
    if ($method === 'GET') {
        $id_pedido     = $_GET['id_pedido']     ?? null;
        $id_entregador = $_GET['id_entregador'] ?? null;

        // Seleção explícita para evitar colisões entre e.nome (recebedor) e c.nome (cliente)
        $sql    = "SELECT e.*, 
                          p.total, p.status AS pedido_status,
                          c.nome AS cliente_nome, c.telefone AS cliente_telefone, c.cliente_verificado
                   FROM entregas e
                   LEFT JOIN pedidos p  ON e.id_pedido  = p.id_pedido
                   LEFT JOIN clientes c ON p.id_cliente = c.id_cliente
                   WHERE 1=1";
        $params = [];

        if ($id_pedido) {
            $sql     .= " AND e.id_pedido = ?";
            $params[] = $id_pedido;
        }
        if ($id_entregador) {
            $sql     .= " AND e.id_entregador = ?";
            $params[] = $id_entregador;
        }
        $sql .= " ORDER BY e.data_envio DESC";

        $q = $pdo->prepare($sql);
        $q->execute($params);
        $data = $q->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode(["success" => true, "data" => $data]);
        exit;
    }

    // ── POST — Registar ou Atualizar Dados de Entrega ──────────────
    elseif ($method === 'POST') {
        $d = json_decode(file_get_contents("php://input"), true) ?? [];

        if (empty($d['id_pedido'])) {
            echo json_encode(["success" => false, "message" => "id_pedido obrigatório."]);
            exit;
        }

        // Verifica se já existe uma guia de entrega associada a este pedido
        $check = $pdo->prepare("SELECT id_entrega FROM entregas WHERE id_pedido = ?");
        $check->execute([$d['id_pedido']]);
        
        if ($check->fetch()) {
            // Se já existir, faz um UPDATE dinâmico com os dados de envio
            $q = $pdo->prepare("UPDATE entregas SET
                status          = ?,
                nome            = ?,
                cidade          = ?,
                endereco        = ?,
                detalhe_entrega = ?,
                distancia       = ?,
                preco_entrega   = ?,
                data_envio      = ?,
                data_entrega    = ?
                WHERE id_pedido = ?");
            $q->execute([
                $d['status']          ?? 'pendente',
                $d['nome']            ?? '',
                $d['cidade']          ?? 'Luanda',
                $d['endereco']        ?? '',
                $d['detalhe_entrega'] ?? null,
                $d['distancia']       ?? null,
                $d['preco_entrega']   ?? null,
                $d['data_envio']      ?? date('Y-m-d H:i:s'),
                $d['data_entrega']    ?? null,
                $d['id_pedido'],
            ]);
            
            echo json_encode(["success" => true, "actualizado" => true]);
            exit;
        }

        // Se for um novo registo de distribuição, faz o INSERT
        $q = $pdo->prepare("INSERT INTO entregas
            (id_pedido, status, nome, cidade, endereco, detalhe_entrega,
             distancia, preco_entrega, data_envio, data_entrega)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $q->execute([
            $d['id_pedido'],
            $d['status']          ?? 'pendente',
            $d['nome']            ?? '',
            $d['cidade']          ?? 'Luanda',
            $d['endereco']        ?? '',
            $d['detalhe_entrega'] ?? null,
            $d['distancia']       ?? null,
            $d['preco_entrega']   ?? null,
            $d['data_envio']      ?? date('Y-m-d H:i:s'),
            $d['data_entrega']    ?? null,
        ]);
        
        echo json_encode(["success" => true, "id" => $pdo->lastInsertId()]);
        exit;
    }

    // ── PUT — Atualizar Estado de Entrega (Usado pela App do Estafeta) ──
    elseif ($method === 'PUT') {
        $d = json_decode(file_get_contents("php://input"), true) ?? [];
        $id_pedido = $d['id_pedido'] ?? $id;

        if (!$id_pedido || !isset($d['status'])) {
            echo json_encode(["success" => false, "message" => "id_pedido e status são obrigatórios."]);
            exit;
        }

        $q = $pdo->prepare("UPDATE entregas SET status = ? WHERE id_pedido = ?");
        $q->execute([$d['status'], $id_pedido]);
        
        echo json_encode(["success" => true, "message" => "Estado de entrega actualizado."]);
        exit;
    }

    // ── DELETE — Remover Registo de Entrega ───────────────────────
    elseif ($method === 'DELETE') {
        if (!$id) {
            echo json_encode(["success" => false, "message" => "ID da entrega em falta."]);
            exit;
        }
        $pdo->prepare("DELETE FROM entregas WHERE id_entrega = ?")->execute([$id]);
        echo json_encode(["success" => true, "message" => "Registo de entrega removido."]);
        exit;
    }

    else {
        echo json_encode(["success" => false, "message" => "Método não suportado."]);
    }

} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => "Erro na gestão de entregas: " . $e->getMessage()]);
}
?>