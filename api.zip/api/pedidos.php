<?php
// Inclui a conexão de produção e as diretivas unificadas de CORS
require_once "config.php";

// Garante que o retorno é interpretado estritamente como JSON estruturado
header("Content-Type: application/json; charset=UTF-8");

$method = $_SERVER['REQUEST_METHOD'];
$id     = isset($_GET['id']) ? intval($_GET['id']) : 0;

/* ══════════════════════════════════════════════════════════════
    HELPERS — Motores Regras de Negócio e Contabilidade
══════════════════════════════════════════════════════════════ */

function registarEntradaFinanceira(PDO $pdo, int $id_pedido, float $total): void {
    $q = $pdo->prepare("SELECT COUNT(*) FROM financeiro WHERE observacao = ? AND tipo = 'ENTRADA'");
    $q->execute(["Pedido #$id_pedido"]);
    if ((int)$q->fetchColumn() > 0) return;

    $pdo->prepare("
        INSERT INTO financeiro
            (tipo, descricao, valor, categoria, forma_pagamento, status, observacao, data_movimento)
        VALUES ('ENTRADA', ?, ?, 'Venda Loja', 'DINHEIRO', 'CONFIRMADO', ?, NOW())
    ")->execute([
        "Venda realizada - Pedido #$id_pedido",
        round($total, 2),
        "Pedido #$id_pedido",
    ]);
}

function reverterEntradaFinanceira(PDO $pdo, int $id_pedido): void {
    $pdo->prepare("
        UPDATE financeiro
        SET status = 'CANCELADO',
            observacao = CONCAT(IFNULL(observacao,''), ' - CANCELADO')
        WHERE observacao = ? AND tipo = 'ENTRADA' AND status = 'CONFIRMADO'
    ")->execute(["Pedido #$id_pedido"]);
}

function getLimiteVip(PDO $pdo): int {
    try {
        $q = $pdo->query("SELECT compras_vip FROM configuracao_loja LIMIT 1");
        $v = $q ? (int)$q->fetchColumn() : 0;
        return $v > 0 ? $v : 10;
    } catch (Exception $e) { return 10; }
}

function creditarBonus(PDO $pdo, int $id_pedido, int $id_cliente): float {
    $qv = $pdo->prepare("SELECT cliente_verificado FROM clientes WHERE id_cliente = ?");
    $qv->execute([$id_cliente]);
    if (!(bool)$qv->fetchColumn()) return 0.0;

    $qb = $pdo->prepare("
        SELECT COALESCE(SUM(pr.bonus_saldo), 0)
        FROM itens_pedido ip
        JOIN produtos pr ON pr.id_produto = ip.id_produto
        WHERE ip.id_pedido = ? AND pr.bonus_saldo > 0
    ");
    $qb->execute([$id_pedido]);
    $bonus = round((float)$qb->fetchColumn(), 2);
    if ($bonus <= 0) return 0.0;

    $qC = $pdo->prepare("SELECT id_cartao FROM cartao WHERE id_cliente = ? AND ativo = 1 LIMIT 1");
    $qC->execute([$id_cliente]);
    $row = $qC->fetch(PDO::FETCH_ASSOC);

    if ($row) {
        $id_cartao = (int)$row['id_cartao'];
        $pdo->prepare("UPDATE cartao SET saldo_bonus = saldo_bonus + ? WHERE id_cartao = ?")
            ->execute([$bonus, $id_cartao]);
    } else {
        $qr = "LOPOS-" . $id_cliente . "-" . bin2hex(random_bytes(6));
        $pdo->prepare("INSERT INTO cartao (id_cliente, saldo_bonus, qr_code, ativo, paleta_id) VALUES (?, ?, ?, 1, 'indigo')")
            ->execute([$id_cliente, $bonus, $qr]);
        $id_cartao = (int)$pdo->lastInsertId();
    }

    $pdo->prepare("UPDATE clientes SET saldo_bonus = saldo_bonus + ? WHERE id_cliente = ?")
        ->execute([$bonus, $id_cliente]);

    $pdo->prepare("INSERT INTO bonus_transacoes (id_cartao, valor, tipo, descricao) VALUES (?, ?, 'ganho', ?)")
        ->execute([$id_cartao, $bonus, "Bónus de compra — Pedido #$id_pedido"]);

    return $bonus;
}

function atualizarHistoricoStatus(PDO $pdo, int $id_pedido, string $status): void {
    foreach (['historico_vendas', 'historico_cliente'] as $t) {
        try {
            if ($pdo->query("SHOW TABLES LIKE '$t'")->fetch()) {
                $pdo->prepare("UPDATE $t SET status = ? WHERE id_pedido = ?")
                    ->execute([$status, $id_pedido]);
            }
        } catch (Exception $e) { /* Suprime logs silenciosamente */ }
    }
}

/* ══════════════════════════════════════════════════════════════
    ROTAS E OPERAÇÕES LOGÍSTICAS
══════════════════════════════════════════════════════════════ */
try {

    /* ── MÉTODOS DE LEITURA (GET) ── */
    if ($method === 'GET') {
        if ($id) {
            $q = $pdo->prepare("
                SELECT p.*,
                       c.nome, c.email, c.telefone, c.cliente_verificado,
                       e.endereco AS end_entrega, e.detalhe_entrega, e.cidade,
                       e.distancia, e.preco_entrega, e.id_entregador
                FROM pedidos p
                LEFT JOIN clientes c ON p.id_cliente = c.id_cliente
                LEFT JOIN entregas e ON e.id_pedido  = p.id_pedido
                WHERE p.id_pedido = ?
            ");
            $q->execute([$id]);
            $pedido = $q->fetch(PDO::FETCH_ASSOC);
            
            if ($pedido) {
                $qi = $pdo->prepare("
                    SELECT ip.*, pr.img1, pr.estoque,
                           pr.status AS produto_status, pr.bonus_saldo
                    FROM itens_pedido ip
                    LEFT JOIN produtos pr ON ip.id_produto = pr.id_produto
                    WHERE ip.id_pedido = ?
                ");
                $qi->execute([$id]);
                
                // Sanitização e formatação tipada dos itens internos do pedido
                $pedido['itens'] = array_map(function($item) {
                    $item['id_item']        = (int)$item['id_item'];
                    $item['id_produto']     = (int)$item['id_produto'];
                    $item['quantidade']     = (int)$item['quantidade'];
                    $item['preco_unitario'] = (float)$item['preco_unitario'];
                    $item['subtotal']       = (float)$item['subtotal'];
                    $item['estoque']        = (int)($item['estoque'] ?? 0);
                    $item['bonus_saldo']    = (float)($item['bonus_saldo'] ?? 0);
                    return $item;
                }, $qi->fetchAll(PDO::FETCH_ASSOC));

                // Casting explícito das propriedades do objeto principal
                $pedido['id_pedido']          = (int)$pedido['id_pedido'];
                $pedido['id_cliente']         = (int)$pedido['id_cliente'];
                $pedido['total']              = (float)$pedido['total'];
                $pedido['desconto']           = (float)$pedido['desconto'];
                $pedido['taxa_entrega']       = (float)$pedido['taxa_entrega'];
                $pedido['distancia']          = (float)($pedido['distancia'] ?? 0);
                $pedido['preco_entrega']      = (float)($pedido['preco_entrega'] ?? 0);
                $pedido['id_entregador']      = (int)($pedido['id_entregador'] ?? 0);
                $pedido['cliente_verificado'] = (bool)$pedido['cliente_verificado'];
            }
            
            echo json_encode(["success" => true, "data" => $pedido]);
            exit;
        }

        // Filtros globais de listagem do painel administrativo
        $status = $_GET['status'] ?? '';
        $busca  = $_GET['busca']  ?? '';
        $sql    = "
            SELECT p.*,
                   c.nome, c.email, c.telefone, c.cliente_verificado,
                   e.endereco AS end_entrega, e.detalhe_entrega, e.cidade,
                   e.distancia, e.preco_entrega, e.id_entregador
            FROM pedidos p
            LEFT JOIN clientes c ON p.id_cliente = c.id_cliente
            LEFT JOIN entregas e ON e.id_pedido  = p.id_pedido
            WHERE 1=1";
        
        $params = [];
        if ($status && $status !== 'todos') { $sql .= " AND p.status = ?"; $params[] = $status; }
        if ($busca) {
            $like = "%$busca%";
            $sql .= " AND (c.nome LIKE ? OR c.email LIKE ? OR CAST(p.id_pedido AS CHAR) LIKE ?)";
            $params[] = $like; $params[] = $like; $params[] = $like;
        }
        $sql .= " ORDER BY c.cliente_verificado DESC, p.criado_em DESC";
        
        $q = $pdo->prepare($sql);
        $q->execute($params);
        $rawPedidos = $q->fetchAll(PDO::FETCH_ASSOC);
        
        // Casting estruturado para mapeamento limpo na renderização de tabelas/listas
        $pedidos = array_map(function($p) {
            $p['id_pedido']          = (int)$p['id_pedido'];
            $p['total']              = (float)$p['total'];
            $p['desconto']           = (float)$p['desconto'];
            $p['taxa_entrega']       = (float)$p['taxa_entrega'];
            $p['cliente_verificado'] = (bool)$p['cliente_verificado'];
            return $p;
        }, $rawPedidos);

        $contadores = [];
        foreach ($pdo->query("SELECT status, COUNT(*) n FROM pedidos GROUP BY status")->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $contadores[$r['status']] = (int)$r['n'];
        }
        
        echo json_encode(["success" => true, "data" => $pedidos, "total" => count($pedidos), "contadores" => $contadores]);
        exit;
    }

    /* ── REGISTO DE NOVOS PEDIDOS (POST) ── */
    if ($method === 'POST') {
        $d = json_decode(file_get_contents("php://input"), true) ?? [];

        if (empty($d['id_cliente']) || !isset($d['total'])) {
            echo json_encode(["success" => false, "message" => "Dados estruturais insuficientes para registrar venda."]); 
            exit;
        }

        $pdo->beginTransaction();
        $itens = $d['itens'] ?? [];

        /* Validação Atómica Contraintuitiva de Stock */
        $erros = [];
        foreach ($itens as $item) {
            $id_prod = intval($item['id_produto'] ?? $item['id'] ?? 0);
            $qtd     = intval($item['quantidade'] ?? 1);
            if (!$id_prod) continue;
            
            $qs = $pdo->prepare("SELECT nome, estoque, status FROM produtos WHERE id_produto = ? FOR UPDATE");
            $qs->execute([$id_prod]);
            $p = $qs->fetch(PDO::FETCH_ASSOC);
            
            if (!$p)                           $erros[] = "Produto #$id_prod indisponível no catálogo.";
            elseif ($p['status'] === 'descontinuado') $erros[] = "O item \"{$p['nome']}\" foi permanentemente descontinuado.";
            elseif ((int)$p['estoque'] < $qtd)        $erros[] = "Ruptura de stock em \"{$p['nome']}\" (Disponível: {$p['estoque']} | Solicitado: $qtd).";
        }
        
        if ($erros) {
            $pdo->rollBack();
            echo json_encode(["success" => false, "message" => implode(" | ", $erros), "erros" => $erros]); 
            exit;
        }

        /* Validação de Existência do Cliente */
        $qcli = $pdo->prepare("SELECT id_cliente FROM clientes WHERE id_cliente = ?");
        $qcli->execute([intval($d['id_cliente'])]);
        if (!$qcli->fetch()) {
            $pdo->rollBack();
            echo json_encode(["success" => false, "message" => "O cliente associado não existe na base de dados."]); 
            exit;
        }

        /* Criação do Lote do Pedido */
        $pdo->prepare("
            INSERT INTO pedidos (id_cliente, total, desconto, taxa_entrega, endereco, status)
            VALUES (?, ?, ?, ?, ?, ?)
        ")->execute([
            $d['id_cliente'], $d['total'],
            $d['desconto']     ?? 0,
            $d['taxa_entrega'] ?? 0,
            $d['endereco']     ?? '',
            $d['status']       ?? 'pendente',
        ]);
        $id_pedido = (int)$pdo->lastInsertId();

        /* Inserção de Itens vinculados e atualização da flag de estado do stock */
        foreach ($itens as $item) {
            $id_prod = intval($item['id_produto'] ?? $item['id'] ?? 0);
            $qtd     = intval($item['quantidade'] ?? 1);
            $preco   = floatval($item['preco'] ?? 0);
            if (!$id_prod) continue;

            $pdo->prepare("
                INSERT INTO itens_pedido (id_pedido, id_produto, nome_produto, quantidade, preco_unitario, subtotal)
                SELECT ?, id_produto, nome, ?, ?, ? FROM produtos WHERE id_produto = ?
            ")->execute([$id_pedido, $qtd, $preco, $qtd * $preco, $id_prod]);

            $pdo->prepare("
                UPDATE produtos SET
                    estoque = GREATEST(0, estoque - ?),
                    status  = CASE
                        WHEN status = 'descontinuado'                   THEN 'descontinuado'
                        WHEN GREATEST(0, estoque - ?) <= 0              THEN 'esgotado'
                        WHEN GREATEST(0, estoque - ?) <= estoque_minimo THEN 'esgotado'
                        ELSE 'disponivel'
                    END
                WHERE id_produto = ?
            ")->execute([$qtd, $qtd, $qtd, $id_prod]);
        }

        $pdo->commit();
        echo json_encode([
            "success"   => true,
            "id_pedido" => $id_pedido,
            "id"        => $id_pedido,
            "message"   => "Pedido #$id_pedido gerado na fila. Regras VIP processadas aquando da entrega definitiva.",
        ]);
        exit;
    }

    /* ── TRANSAÇÕES DE ESTADO (PUT) ── */
    if ($method === 'PUT') {
        $d          = json_decode(file_get_contents("php://input"), true) ?? [];
        $id_pedido  = intval($d['id_pedido'] ?? $id);
        $novoStatus = trim($d['status'] ?? '');

        if (!$id_pedido || !$novoStatus) {
            echo json_encode(["success" => false, "message" => "Identificadores obrigatórios em falta (id_pedido ou status)."]); 
            exit;
        }

        $statusPermitidos = ['pendente','pago','reservado','enviado','entregue','cancelado'];
        if (!in_array($novoStatus, $statusPermitidos)) {
            echo json_encode(["success" => false, "message" => "O estado especificado é inválido: $novoStatus"]); 
            exit;
        }

        $pdo->beginTransaction();

        $qAtual = $pdo->prepare("
            SELECT p.status, p.id_cliente, p.total,
                   c.cliente_verificado, c.compras_realizadas
            FROM pedidos p
            JOIN clientes c ON c.id_cliente = p.id_cliente
            WHERE p.id_pedido = ?
        ");
        $qAtual->execute([$id_pedido]);
        $pedidoAtual = $qAtual->fetch(PDO::FETCH_ASSOC);

        if (!$pedidoAtual) {
            $pdo->rollBack();
            echo json_encode(["success" => false, "message" => "Pedido #$id_pedido não localizado para transição."]); 
            exit;
        }

        $statusAtual   = $pedidoAtual['status'];
        $totalPedido   = (float)$pedidoAtual['total'];
        $id_cliente    = (int)$pedidoAtual['id_cliente'];
        $eraVerificado = (bool)$pedidoAtual['cliente_verificado'];

        $bonus_ganho = 0.0;
        $tornou_vip  = false;
        $msgExtra    = "";

        /* Regras de Fecho Logístico: ENTREGUE */
        if ($novoStatus === 'entregue' && $statusAtual !== 'entregue') {

            registarEntradaFinanceira($pdo, $id_pedido, $totalPedido);

            $pdo->prepare("UPDATE entregas SET status = 'entregue', data_entrega = NOW() WHERE id_pedido = ?")
                ->execute([$id_pedido]);

            $pdo->prepare("UPDATE clientes SET compras_realizadas = compras_realizadas + 1 WHERE id_cliente = ?")
                ->execute([$id_cliente]);

            $limiteVip = getLimiteVip($pdo);
            $qCompras  = $pdo->prepare("SELECT compras_realizadas FROM clientes WHERE id_cliente = ?");
            $qCompras->execute([$id_cliente]);
            $comprasAgora = (int)$qCompras->fetchColumn();

            if (!$eraVerificado && $comprasAgora >= $limiteVip) {
                $pdo->prepare("
                    UPDATE clientes
                    SET cliente_verificado = 1, data_verificacao = NOW()
                    WHERE id_cliente = ? AND cliente_verificado = 0
                ")->execute([$id_cliente]);
                $tornou_vip = true;
                $msgExtra  .= " Cliente promovido! Atingiu $limiteVip entregas bem-sucedidas (VERIFICADO LOPOS).";
            }

            if ($eraVerificado || $tornou_vip) {
                $bonus_ganho = creditarBonus($pdo, $id_pedido, $id_cliente);
                if ($bonus_ganho > 0) {
                    $fmt       = number_format($bonus_ganho, 2, ',', '.');
                    $msgExtra .= " Bónus de {$fmt} AOA injetado no cartão digital.";
                }
            }

            $msgExtra .= " Lançamento de contabilidade de " . number_format($totalPedido, 2, ',', '.') . " AOA consolidado.";
            atualizarHistoricoStatus($pdo, $id_pedido, 'entregue');
        }

        /* Regras de Estorno Logístico: CANCELADO */
        if ($novoStatus === 'cancelado' && $statusAtual !== 'cancelado') {

            $qi = $pdo->prepare("SELECT id_produto, quantidade FROM itens_pedido WHERE id_pedido = ?");
            $qi->execute([$id_pedido]);
            foreach ($qi->fetchAll(PDO::FETCH_ASSOC) as $item) {
                $pdo->prepare("
                    UPDATE produtos SET
                        estoque = estoque + ?,
                        status  = CASE
                            WHEN status = 'descontinuado' THEN 'descontinuado'
                            WHEN (estoque + ?) > 0        THEN 'disponivel'
                            ELSE status
                        END
                    WHERE id_produto = ?
                ")->execute([$item['quantidade'], $item['quantidade'], $item['id_produto']]);
            }

            if ($statusAtual === 'entregue') {
                reverterEntradaFinanceira($pdo, $id_pedido);

                $pdo->prepare("
                    UPDATE clientes
                    SET compras_realizadas = GREATEST(0, compras_realizadas - 1)
                    WHERE id_cliente = ?
                ")->execute([$id_cliente]);

                if ($eraVerificado) {
                    $qB = $pdo->prepare("
                        SELECT COALESCE(SUM(pr.bonus_saldo), 0)
                        FROM itens_pedido ip
                        JOIN produtos pr ON pr.id_produto = ip.id_produto
                        WHERE ip.id_pedido = ? AND pr.bonus_saldo > 0
                    ");
                    $qB->execute([$id_pedido]);
                    $bonusCreditado = round((float)$qB->fetchColumn(), 2);

                    if ($bonusCreditado > 0) {
                        $pdo->prepare("UPDATE clientes SET saldo_bonus = GREATEST(0, saldo_bonus - ?) WHERE id_cliente = ?")
                            ->execute([$bonusCreditado, $id_cliente]);
                        $pdo->prepare("UPDATE cartao SET saldo_bonus = GREATEST(0, saldo_bonus - ?) WHERE id_cliente = ? AND ativo = 1")
                            ->execute([$bonusCreditado, $id_cliente]);

                        $qCId = $pdo->prepare("SELECT id_cartao FROM cartao WHERE id_cliente = ? AND ativo = 1 LIMIT 1");
                        $qCId->execute([$id_cliente]);
                        $cId = $qCId->fetchColumn();
                        if ($cId) {
                            $pdo->prepare("INSERT INTO bonus_transacoes (id_cartao, valor, tipo, descricao) VALUES (?, ?, 'debito', ?)")
                                ->execute([$cId, $bonusCreditado, "Estorno / Cancelamento — Pedido #$id_pedido"]);
                        }
                    }
                }
                $msgExtra = " Contabilidade, histórico de compras e saldo de bónus estornados.";
            } else {
                $msgExtra = " Stock estornado e devolvido à prateleira.";
            }

            $pdo->prepare("UPDATE entregas SET status = 'cancelado' WHERE id_pedido = ?")->execute([$id_pedido]);
            atualizarHistoricoStatus($pdo, $id_pedido, 'cancelado');
        }

        /* Sincronização de Envio Logístico (Despacho) */
        if ($novoStatus === 'enviado' && isset($d['id_entregador'])) {
            $pdo->prepare("UPDATE entregas SET status = 'enviado', id_entregador = ? WHERE id_pedido = ?")
                ->execute([intval($d['id_entregador']), $id_pedido]);
        }

        /* Sincronização de Reserva Logística */
        if ($novoStatus === 'reservado' && isset($d['id_entregador'])) {
            $pdo->prepare("UPDATE entregas SET id_entregador = ? WHERE id_pedido = ?")
                ->execute([intval($d['id_entregador']), $id_pedido]);
        }

        // Consolida a transição de estado da ordem de venda principal
        $pdo->prepare("UPDATE pedidos SET status = ? WHERE id_pedido = ?")->execute([$novoStatus, $id_pedido]);

        $pdo->commit();

        echo json_encode([
            "success"     => true,
            "bonus_ganho" => (float)$bonus_ganho,
            "tornou_vip"  => (bool)$tornou_vip,
            "message"     => "Transição concluída para '$novoStatus'." . $msgExtra,
        ]);
        exit;
    }

    /* ── PURGA DE REGISTOS (DELETE) ── */
    if ($method === 'DELETE') {
        if (!$id) {
            echo json_encode(["success" => false, "message" => "Identificador inválido para remoção."]);
            exit;
        }
        $pdo->prepare("DELETE FROM pedidos WHERE id_pedido = ?")->execute([$id]);
        echo json_encode(["success" => true, "message" => "Pedido permanentemente removido da base de dados."]);
        exit;
    }

} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo json_encode([
        "success" => false, 
        "message" => "Exceção no barramento de faturação LOPOS: " . $e->getMessage()
    ]);
    exit;
}

// Resposta unificada para métodos não mapeados na rota mestre
echo json_encode(["success" => false, "message" => "Verbo HTTP não suportado nesta interface."]);
?>