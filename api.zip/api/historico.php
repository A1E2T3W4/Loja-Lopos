<?php
// Inclui a conexão de produção e as configurações globais de CORS
require_once 'config.php';

// Define o tipo de conteúdo padrão como JSON em UTF-8
header("Content-Type: application/json; charset=UTF-8");

$method = $_SERVER['REQUEST_METHOD'];
$data   = json_decode(file_get_contents("php://input"), true) ?? [];

if ($method === 'POST') {
    
    // Validação inicial de integridade do payload
    if (empty($data['id_cliente']) || empty($data['id_pedido']) || !isset($data['total'])) {
        echo json_encode(["success" => false, "message" => "Dados incompletos para processar histórico."]);
        exit;
    }

    try {
        $pdo->beginTransaction();

        // 1. Inserir o registo no histórico de vendas da plataforma
        $stmt = $pdo->prepare("
            INSERT INTO historico_vendas
                (id_cliente, id_pedido, total, status, data_compra)
            VALUES
                (:id_cliente, :id_pedido, :total, :status, :data_compra)
        ");
        $stmt->execute([
            ':id_cliente'  => intval($data['id_cliente']),
            ':id_pedido'   => intval($data['id_pedido']),
            ':total'       => floatval($data['total']),
            ':status'      => $data['status'] ?? 'concluído',
            ':data_compra' => $data['data_compra'] ?? date('Y-m-d H:i:s'),
        ]);

        $id_historico = $pdo->lastInsertId();

        // 2. Incrementar o contador de compras realizadas na ficha do cliente
        $pdo->prepare("
            UPDATE clientes 
            SET compras_realizadas = compras_realizadas + 1
            WHERE id_cliente = :id
        ")->execute([':id' => $data['id_cliente']]);

        // 3. Verificar o volume acumulado para atribuição do estatuto de verificado
        $stmt = $pdo->prepare("SELECT compras_realizadas FROM clientes WHERE id_cliente = :id");
        $stmt->execute([':id' => $data['id_cliente']]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row && $row['compras_realizadas'] >= 10) {
            // Promove o cliente para verificado
            $pdo->prepare("UPDATE clientes SET cliente_verificado = 1 WHERE id_cliente = :id")
                ->execute([':id' => $data['id_cliente']]);

            // Gestão do Cartão de Bónus e Fidelidade
            $stmtCartao = $pdo->prepare("SELECT id_cartao FROM cartao WHERE id_cliente = :id");
            $stmtCartao->execute([':id' => $data['id_cliente']]);
            $cartaoExistente = $stmtCartao->fetch(PDO::FETCH_ASSOC);
            
            if (!$cartaoExistente) {
                // Criação do cartão com geração de QR Code seguro para evitar campos nulos
                $qr = "LOPOS-CARTAO-{$data['id_cliente']}-" . bin2hex(random_bytes(8));
                $pdo->prepare("
                    INSERT INTO cartao (id_cliente, saldo_bonus, qr_code, ativo, paleta_id, criado_em) 
                    VALUES (:id, 5000, :qr_code, 1, 'indigo', NOW())
                ")->execute([
                    ':id'      => $data['id_cliente'],
                    ':qr_code' => $qr
                ]);
            } else {
                // Se o cartão já existir por consultas prévias do scanner, credita o bónus extra de 5.000 AOA
                $pdo->prepare("UPDATE cartao SET saldo_bonus = saldo_bonus + 5000, ativo = 1 WHERE id_cliente = :id")
                    ->execute([':id' => $data['id_cliente']]);
            }
        }

        // 4. Captura a ficha consolidada e atualizada do cliente (Join com a tabela cartao)
        $stmt = $pdo->prepare("
            SELECT 
                c.id_cliente, c.nome, c.email, c.telefone, c.foto_url,
                c.cliente_verificado, c.compras_realizadas,
                ca.id_cartao, ca.saldo_bonus, ca.qr_code, 
                ca.ativo AS cartao_ativo, ca.criado_em, ca.paleta_id
            FROM clientes c
            LEFT JOIN cartao ca ON ca.id_cliente = c.id_cliente
            WHERE c.id_cliente = :id
        ");
        $stmt->execute([':id' => $data['id_cliente']]);
        $cliente = $stmt->fetch(PDO::FETCH_ASSOC);

        // Formata o nó de cartões para a estrutura esperada pelo teu State do React Native / React
        $cliente['cartoes_cliente'] = [
            'id_cartao'   => $cliente['id_cartao'] ?? null,
            'saldo_bonus' => (float)($cliente['saldo_bonus'] ?? 0),
            'qr_code'     => $cliente['qr_code'] ?? null,
            'paleta_id'   => $cliente['paleta_id'] ?? 'indigo',
            'ativo'       => (bool)($cliente['cartao_ativo'] ?? 0),
            'criado_em'   => $cliente['criado_em'] ?? null
        ];
        
        // Remove as colunas flat para manter o payload limpo
        unset($cliente['id_cartao'], $cliente['saldo_bonus'], $cliente['qr_code'], $cliente['cartao_ativo'], $cliente['criado_em'], $cliente['paleta_id']);

        $pdo->commit();
        echo json_encode([
            "success"      => true, 
            "id_historico" => (int)$id_historico, 
            "cliente"      => $cliente
        ]);
        exit;

    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        echo json_encode([
            "success" => false, 
            "message" => "Erro ao processar transação de fidelidade: " . $e->getMessage()
        ]);
        exit;
    }
}

// Resposta para métodos HTTP incorretos
http_response_code(405);
echo json_encode(["success" => false, "message" => "Método não suportado."]);
?>