<?php
// Configuração do ambiente
require_once 'config.php';

header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// Resposta rápida para preflight do CORS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Validação estrita de método
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["success" => false, "message" => "Método não permitido."]);
    exit;
}

$input = json_decode(file_get_contents("php://input"), true) ?? [];
$id_cliente = intval($input['id_cliente'] ?? 0);

if ($id_cliente <= 0) {
    echo json_encode(["success" => false, "message" => "Identificador do cliente inválido ou ausente."]);
    exit;
}

try {
    // Consulta otimizada para o perfil do cliente
    $stmt = $pdo->prepare("
        SELECT nome, email, cliente_verificado, compras_realizadas, saldo_bonus
        FROM clientes 
        WHERE id_cliente = ? 
        LIMIT 1
    ");
    $stmt->execute([$id_cliente]);
    $cliente = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$cliente) {
        echo json_encode(["success" => false, "message" => "Cliente não registado no sistema."]);
        exit;
    }

    // Casting explícito para garantir integridade dos dados no Front-end
    $verificado = (bool)$cliente['cliente_verificado'];

    echo json_encode([
        "success"            => true,
        "cliente_verificado" => $verificado,
        "compras_realizadas" => (int)$cliente['compras_realizadas'],
        "saldo_bonus"        => (float)$cliente['saldo_bonus'],
        "message"            => $verificado 
            ? "Status: Cliente verificado." 
            : "Status: Em processamento. A verificação é ativada pelo sistema após a entrega da décima compra."
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => "Erro interno no servidor: " . $e->getMessage()]);
}