<?php
// Inclui a conexão de produção e as diretivas unificadas de CORS
require_once 'config.php';

// Garante a resposta de dados tipada como JSON estruturado
header("Content-Type: application/json; charset=UTF-8");

$method = $_SERVER['REQUEST_METHOD'];

try {

    /* ════════════════════════════════════════════════════════════
        GET — Listagem Dinâmica e Filtrada de Pedidos comerciais
    ════════════════════════════════════════════════════════════ */
    if ($method === 'GET') {
        $tipo          = $_GET['tipo']          ?? 'pendentes';
        $id_entregador = $_GET['id_entregador'] ?? null;

        // Base SQL unificada mapeando as entidades de clientes, entregas e itens do pedido
        $selectBase = "
            SELECT p.id_pedido, p.total, p.desconto, p.taxa_entrega,
                   p.status, p.criado_em, p.qr_code,
                   c.nome, c.telefone, c.cliente_verificado,
                   e.endereco, e.detalhe_entrega, e.cidade,
                   e.distancia, e.preco_entrega, e.id_entregador,
                   GROUP_CONCAT(
                     JSON_OBJECT(
                       'nome_produto',   ip.nome_produto,
                       'quantidade',     ip.quantidade,
                       'subtotal',       ip.subtotal,
                       'preco_unitario', ip.preco_unitario
                     )
                     ORDER BY ip.id_item
                   ) AS itens_json
            FROM pedidos p
            LEFT JOIN clientes c      ON p.id_cliente  = c.id_cliente
            LEFT JOIN entregas e      ON p.id_pedido   = e.id_pedido
            LEFT JOIN itens_pedido ip ON p.id_pedido   = ip.id_pedido
        ";

        if ($tipo === 'reservas' && $id_entregador) {
            // Captura as rotas atualmente ativas vinculadas ao estafeta solicitante
            $q = $pdo->prepare($selectBase . "
                WHERE e.id_entregador = ?
                  AND p.status NOT IN ('entregue', 'cancelado')
                GROUP BY p.id_pedido
                ORDER BY p.criado_em DESC
            ");
            $q->execute([intval($id_entregador)]);

        } elseif ($tipo === 'entregues' && $id_entregador) {
            // Histórico completo de conclusões de cargas do entregador especifico
            $q = $pdo->prepare($selectBase . "
                WHERE e.id_entregador = ?
                  AND p.status = 'entregue'
                GROUP BY p.id_pedido
                ORDER BY p.criado_em DESC
            ");
            $q->execute([intval($id_entregador)]);

        } else {
            // Fila pública de entregas: Prioridade máxima algorítmica para Clientes Verificados do LOPOS
            $q = $pdo->prepare($selectBase . "
                WHERE p.status IN ('pendente', 'pago', 'processando')
                  AND (e.id_entregador IS NULL OR e.id_entregador = 0)
                GROUP BY p.id_pedido
                ORDER BY c.cliente_verificado DESC, p.criado_em DESC
            ");
            $q->execute([]);
        }

        $rows = $q->fetchAll(PDO::FETCH_ASSOC);

        // Formatação refinada da árvore JSON para consumo assíncrono
        $result = array_map(function ($row) {
            $itens = [];
            if (!empty($row['itens_json'])) {
                // Tratamento preventivo: garante o encapsulamento em colchetes de array nativo
                $jsonString = trim($row['itens_json']);
                if ($jsonString[0] !== '[') {
                    $jsonString = "[" . $jsonString . "]";
                }
                $decoded = json_decode($jsonString, true);
                if (is_array($decoded)) $itens = $decoded;
            }
            unset($row['itens_json']);
            
            // Castings explícitos para o State do Front-End tipar corretamente
            $row['itens']              = $itens;
            $row['id_pedido']          = (int)$row['id_pedido'];
            $row['total']              = (float)$row['total'];
            $row['desconto']           = (float)($row['desconto'] ?? 0);
            $row['taxa_entrega']       = (float)($row['taxa_entrega'] ?? 0);
            $row['distancia']          = (float)($row['distancia'] ?? 0);
            $row['preco_entrega']      = (float)($row['preco_entrega'] ?? 0);
            $row['id_entregador']      = (int)($row['id_entregador'] ?? 0);
            $row['cliente_verificado'] = (bool)($row['cliente_verificado'] ?? 0);
            
            return $row;
        }, $rows);

        echo json_encode(["success" => true, "data" => $result]);
        exit;
    }

    /* ════════════════════════════════════════════════════════════
        PUT — Modificações de Estado e Regras de Negócio Logísticas
    ════════════════════════════════════════════════════════════ */
    if ($method === 'PUT') {
        $d             = json_decode(file_get_contents("php://input"), true) ?? [];
        $id_pedido     = $d['id_pedido']     ?? null;
        $id_entregador = $d['id_entregador'] ?? null;
        $acao          = $d['acao']          ?? null;

        if (!$id_pedido || !$acao) {
            echo json_encode(["success" => false, "message" => "Dados estruturais incompletos para atualização."]);
            exit;
        }

        $pdo->beginTransaction();

        // ── Ação Estrutural: Reservar Carga para Entrega ──
        if ($acao === 'reservar') {
            if (!$id_entregador) {
                $pdo->rollBack();
                echo json_encode(["success" => false, "message" => "Identificador do entregador é obrigatório para reserva."]);
                exit;
            }

            // Lock de segurança preventivo para evitar concorrência dupla de estafetas no mesmo pedido
            $chk = $pdo->prepare("
                SELECT e.id_entregador, p.status
                FROM entregas e
                JOIN pedidos p ON p.id_pedido = e.id_pedido
                WHERE e.id_pedido = ?
                LIMIT 1
            ");
            $chk->execute([$id_pedido]);
            $atual = $chk->fetch(PDO::FETCH_ASSOC);

            if ($atual && !empty($atual['id_entregador']) && $atual['id_entregador'] != $id_entregador) {
                $pdo->rollBack();
                echo json_encode(["success" => false, "message" => "Este pedido já foi reservado por outro estafeta na fila."]);
                exit;
            }

            if ($atual && in_array($atual['status'], ['entregue', 'cancelado', 'reservado'])) {
                $pdo->rollBack();
                echo json_encode(["success" => false, "message" => "Operação inválida. O pedido encontra-se no estado: " . $atual['status']]);
                exit;
            }

            // 1. Vincula o operador logístico à entrega
            $pdo->prepare("UPDATE entregas SET id_entregador = ? WHERE id_pedido = ?")->execute([$id_entregador, $id_pedido]);

            // 2. Sincroniza estados em cascata no ecossistema comercial
            $pdo->prepare("UPDATE pedidos SET status = 'reservado' WHERE id_pedido = ?")->execute([$id_pedido]);

            if ($pdo->query("SHOW TABLES LIKE 'historico_vendas'")->fetch()) {
                $pdo->prepare("UPDATE historico_vendas SET status = 'reservado' WHERE id_pedido = ? AND status != 'entregue'")->execute([$id_pedido]);
            }

            if ($pdo->query("SHOW TABLES LIKE 'historico_cliente'")->fetch()) {
                $pdo->prepare("UPDATE historico_cliente SET status = 'reservado' WHERE id_pedido = ? AND status != 'entregue'")->execute([$id_pedido]);
            }

            $pdo->commit();
            echo json_encode([
                "success" => true,
                "acao"    => "reservar",
                "message" => "Pedido associado e reservado com sucesso.",
                "status"  => "reservado",
            ]);
            exit;

        // ── Ação Estrutural: Cancelar / Devolver Reserva à Fila Pública ──
        } elseif ($acao === 'cancelar') {

            if ($id_entregador) {
                $chk = $pdo->prepare("SELECT id_entregador FROM entregas WHERE id_pedido = ? LIMIT 1");
                $chk->execute([$id_pedido]);
                $ent = $chk->fetch(PDO::FETCH_ASSOC);
                
                if ($ent && $ent['id_entregador'] != $id_entregador) {
                    $pdo->rollBack();
                    echo json_encode(["success" => false, "message" => "Restrição de segurança. Não possui permissão para revogar esta reserva."]);
                    exit;
                }
            }

            // 1. Liberta o pedido na tabela de entregas
            $pdo->prepare("UPDATE entregas SET id_entregador = NULL WHERE id_pedido = ?")->execute([$id_pedido]);

            // 2. Restaura o status operacional anterior do lote
            $pdo->prepare("UPDATE pedidos SET status = 'processando' WHERE id_pedido = ? AND status = 'reservado'")->execute([$id_pedido]);

            if ($pdo->query("SHOW TABLES LIKE 'historico_vendas'")->fetch()) {
                $pdo->prepare("UPDATE historico_vendas SET status = 'processando' WHERE id_pedido = ? AND status = 'reservado'")->execute([$id_pedido]);
            }

            if ($pdo->query("SHOW TABLES LIKE 'historico_cliente'")->fetch()) {
                $pdo->prepare("UPDATE historico_cliente SET status = 'processando' WHERE id_pedido = ? AND status = 'reservado'")->execute([$id_pedido]);
            }

            $pdo->commit();
            echo json_encode([
                "success" => true,
                "acao"    => "cancelar",
                "message" => "Reserva cancelada. O lote foi devolvido para a fila geral.",
                "status"  => "processando",
            ]);
            exit;

        // ── Ação Estrutural: Confirmar Entrega e Concluir Ciclo de Vida do Pedido ──
        } elseif ($acao === 'entregar') {

            // 1. Marca o encerramento do fluxo na tabela principal de pedidos
            $pdo->prepare("UPDATE pedidos SET status = 'entregue' WHERE id_pedido = ?")->execute([$id_pedido]);

            // 2. Registra o timestamp da entrega na malha logística
            $pdo->prepare("UPDATE entregas SET status = 'entregue', data_entrega = NOW() WHERE id_pedido = ?")->execute([$id_pedido]);

            // 3. Validação adaptável de colunas na tabela de auditoria historico_vendas
            if ($pdo->query("SHOW TABLES LIKE 'historico_vendas'")->fetch()) {
                $temIdEntregador = (bool)$pdo->query("SHOW COLUMNS FROM historico_vendas LIKE 'id_entregador'")->fetch();
                $temDataEntrega  = (bool)$pdo->query("SHOW COLUMNS FROM historico_vendas LIKE 'data_entrega'")->fetch();

                if ($temIdEntregador && $temDataEntrega) {
                    $pdo->prepare("
                        UPDATE historico_vendas
                        SET status = 'entregue', id_entregador = ?, data_entrega = NOW()
                        WHERE id_pedido = ?
                    ")->execute([$id_entregador, $id_pedido]);
                } elseif ($temIdEntregador) {
                    $pdo->prepare("
                        UPDATE historico_vendas SET status = 'entregue', id_entregador = ? WHERE id_pedido = ?
                    ")->execute([$id_entregador, $id_pedido]);
                } else {
                    $pdo->prepare("UPDATE historico_vendas SET status = 'entregue' WHERE id_pedido = ?")->execute([$id_pedido]);
                }
            }

            // 4. Sincronização do painel de histórico do cliente final
            if ($pdo->query("SHOW TABLES LIKE 'historico_cliente'")->fetch()) {
                $pdo->prepare("UPDATE historico_cliente SET status = 'entregue' WHERE id_pedido = ?")->execute([$id_pedido]);
            }

            $pdo->commit();
            echo json_encode([
                "success" => true,
                "acao"    => "entregar",
                "message" => "Parabéns! Ciclo concluído. Pedido marcado como entregue com sucesso.",
                "status"  => "entregue",
            ]);
            exit;

        } else {
            $pdo->rollBack();
            echo json_encode(["success" => false, "message" => "Ação logística desconhecida ou inválida: {$acao}"]);
            exit;
        }
    }

} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo json_encode([
        "success" => false, 
        "message" => "Erro crítico no barramento de logística LOPOS: " . $e->getMessage()
    ]);
    exit;
}

// Resposta para verbos HTTP não suportados na rota de distribuição
http_response_code(405);
echo json_encode(["success" => false, "message" => "Método HTTP não suportado nesta rota logística."]);
?>