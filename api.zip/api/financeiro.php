<?php
// Inclui a conexão de produção e as configurações globais de CORS
require_once 'config.php';

// Define o fuso horário e tipo de conteúdo da API
date_default_timezone_set('Africa/Luanda');
header("Content-Type: application/json; charset=UTF-8");

$method = $_SERVER['REQUEST_METHOD'];

/* ══════════════════════════════════════════════════════════════
    GET — Lista de Movimentos ou Dados do Dashboard Analítico
══════════════════════════════════════════════════════════════ */
if ($method === 'GET') {

    // ── Sub-módulo: Lista Geral do Fluxo de Caixa ──
    if (isset($_GET['tipo']) && $_GET['tipo'] === 'movimentos') {
        try {
            $stmt = $pdo->query("
                SELECT id_financeiro, tipo, descricao, categoria,
                       valor, forma_pagamento, data_movimento,
                       status, observacao
                FROM financeiro
                ORDER BY data_movimento DESC
            ");
            echo json_encode([
                "success" => true,
                "data"    => $stmt->fetchAll(PDO::FETCH_ASSOC),
            ]);
        } catch (Exception $e) {
            echo json_encode(["success" => false, "message" => "Erro ao listar movimentos: " . $e->getMessage()]);
        }
        exit;
    }

    // ── Sub-módulo: Processamento do Dashboard ──
    try {
        $hoje_data  = date("Y-m-d");
        $ontem_data = date("Y-m-d", strtotime("-1 day"));

        // 1. Volume de Vendas de hoje
        $q = $pdo->prepare("
            SELECT COALESCE(SUM(total), 0) FROM historico_vendas
            WHERE DATE(data_compra) = ? AND status NOT IN ('cancelado')
        ");
        $q->execute([$hoje_data]);
        $hoje = (float)$q->fetchColumn();

        // 2. Volume de Vendas de ontem
        $q = $pdo->prepare("
            SELECT COALESCE(SUM(total), 0) FROM historico_vendas
            WHERE DATE(data_compra) = ? AND status NOT IN ('cancelado')
        ");
        $q->execute([$ontem_data]);
        $ontem = (float)$q->fetchColumn();

        // 3. Gráfico Linear — Histórico dos Últimos 7 Dias
        $q = $pdo->query("
            SELECT DATE(data_compra) AS dia, COALESCE(SUM(total), 0) AS total
            FROM historico_vendas
            WHERE DATE(data_compra) >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
              AND status NOT IN ('cancelado')
            GROUP BY DATE(data_compra)
        ");
        
        $porDia = [];
        foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $porDia[$r['dia']] = (float)$r['total'];
        }
        
        $ultimos7 = [];
        for ($i = 6; $i >= 0; $i--) {
            $data_iteracao = date("Y-m-d", strtotime("-$i days"));
            $ultimos7[]    = $porDia[$data_iteracao] ?? 0;
        }

        // 4. Receita consolidada do mês atual
        $q = $pdo->query("
            SELECT COALESCE(SUM(total), 0) FROM historico_vendas
            WHERE status NOT IN ('cancelado')
              AND MONTH(data_compra) = MONTH(CURDATE())
              AND YEAR(data_compra)  = YEAR(CURDATE())
        ");
        $receitaMes = (float)$q->fetchColumn();

        // 5. Receita consolidada do mês anterior (para cálculo de conversão/crescimento)
        $q = $pdo->query("
            SELECT COALESCE(SUM(total), 0) FROM historico_vendas
            WHERE status NOT IN ('cancelado')
              AND MONTH(data_compra) = MONTH(DATE_SUB(CURDATE(), INTERVAL 1 MONTH))
              AND YEAR(data_compra)  = YEAR(DATE_SUB(CURDATE(), INTERVAL 1 MONTH))
        ");
        $receitaMesAnt = (float)$q->fetchColumn();

        // 6. Balanço manual consolidado (Entradas vs Saídas da tesouraria)
        $q = $pdo->query("
            SELECT
                COALESCE(SUM(CASE WHEN tipo='ENTRADA' AND status='CONFIRMADO' THEN valor ELSE 0 END), 0) AS entradas,
                COALESCE(SUM(CASE WHEN tipo='SAIDA'   AND status='CONFIRMADO' THEN valor ELSE 0 END), 0) AS saidas
            FROM financeiro
        ");
        $totais   = $q->fetch(PDO::FETCH_ASSOC);
        $entradas = (float)($totais['entradas'] ?? 0);
        $saidas   = (float)($totais['saidas']   ?? 0);

        echo json_encode([
            "success"         => true,
            "total"           => $hoje,
            "total_ontem"     => $ontem,
            "ultimos7"        => $ultimos7,
            "receita_mes"     => $receitaMes,
            "receita_mes_ant" => $receitaMesAnt,
            "entradas_total"  => $entradas,
            "saidas_total"    => $saidas,
            "saldo"           => $entradas - $saidas,
        ]);

    } catch (Exception $e) {
        // Fallback estruturado para manter o front-end React funcional mesmo em falha de BD
        echo json_encode([
            "success"         => false,
            "message"         => "Erro no processamento analítico: " . $e->getMessage(),
            "total"           => 0, 
            "total_ontem"     => 0,
            "ultimos7"        => array_fill(0, 7, 0),
            "receita_mes"     => 0, 
            "receita_mes_ant" => 0,
            "entradas_total"  => 0, 
            "saidas_total"    => 0, 
            "saldo"           => 0,
        ]);
    }
    exit;
}

/* ══════════════════════════════════════════════════════════════
    POST — Inserir Novo Movimento de Caixa
══════════════════════════════════════════════════════════════ */
if ($method === 'POST') {
    $d = json_decode(file_get_contents("php://input"), true) ?? [];

    $tipo      = $d['tipo']            ?? 'ENTRADA';
    $descricao = $d['descricao']       ?? '';
    $valor     = floatval($d['valor']  ?? 0);
    $categoria = $d['categoria']       ?? 'Outro';
    $forma_pag = $d['forma_pagamento'] ?? 'DINHEIRO';
    $observacao= $d['observacao']       ?? '';
    $status    = $d['status']          ?? 'CONFIRMADO';

    if (!$descricao || !$valor) {
        echo json_encode(["success" => false, "message" => "Descrição e valor são obrigatórios."]);
        exit;
    }

    try {
        $pdo->prepare("
            INSERT INTO financeiro
              (tipo, descricao, valor, categoria, forma_pagamento, observacao, status, data_movimento)
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
        ")->execute([$tipo, $descricao, $valor, $categoria, $forma_pag, $observacao, $status]);

        echo json_encode([
            "success" => true,
            "message" => "Movimento registado com sucesso.",
            "id"      => $pdo->lastInsertId(),
        ]);
    } catch (Exception $e) {
        echo json_encode(["success" => false, "message" => "Erro ao salvar movimento: " . $e->getMessage()]);
    }
    exit;
}

/* ══════════════════════════════════════════════════════════════
    PUT — Atualizar Lançamento Financeiro Existente
══════════════════════════════════════════════════════════════ */
if ($method === 'PUT') {
    $d  = json_decode(file_get_contents("php://input"), true) ?? [];
    $id = intval($d['id_financeiro'] ?? 0);

    if (!$id) {
        echo json_encode(["success" => false, "message" => "ID do movimento em falta."]);
        exit;
    }

    try {
        $pdo->prepare("
            UPDATE financeiro
            SET tipo = ?, descricao = ?, valor = ?, categoria = ?,
                forma_pagamento = ?, observacao = ?, status = ?
            WHERE id_financeiro = ?
        ")->execute([
            $d['tipo']            ?? 'ENTRADA',
            $d['descricao']       ?? '',
            floatval($d['valor']  ?? 0),
            $d['categoria']       ?? 'Outro',
            $d['forma_pagamento'] ?? 'DINHEIRO',
            $d['observacao']      ?? '',
            $d['status']          ?? 'CONFIRMADO',
            $id,
        ]);

        echo json_encode(["success" => true, "message" => "Movimento actualizado com sucesso."]);
    } catch (Exception $e) {
        echo json_encode(["success" => false, "message" => "Erro ao actualizar movimento: " . $e->getMessage()]);
    }
    exit;
}

/* ══════════════════════════════════════════════════════════════
    DELETE — Estornar / Eliminar Lançamento Financeiro
══════════════════════════════════════════════════════════════ */
if ($method === 'DELETE') {
    $id = intval($_GET['id'] ?? 0);

    if (!$id) {
        echo json_encode(["success" => false, "message" => "ID em falta."]);
        exit;
    }

    try {
        $pdo->prepare("DELETE FROM financeiro WHERE id_financeiro = ?")->execute([$id]);
        echo json_encode(["success" => true, "message" => "Movimento eliminado com sucesso."]);
    } catch (Exception $e) {
        echo json_encode(["success" => false, "message" => "Erro ao eliminar movimento: " . $e->getMessage()]);
    }
    exit;
}

// Resposta padrão para métodos não mapeados
http_response_code(405);
echo json_encode(["success" => false, "message" => "Método não suportado."]);
?>