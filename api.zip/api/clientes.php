<?php
// Inclui a conexão de produção corrigida e os cabeçalhos CORS globais
require_once 'config.php';

// Define o tipo de conteúdo como JSON em UTF-8
header("Content-Type: application/json; charset=UTF-8");

$method = $_SERVER['REQUEST_METHOD'];
$id     = isset($_GET['id']) ? intval($_GET['id']) : 0;

try {

    // ── GET — Listar ou Procurar Clientes ───────────────────
    if ($method === 'GET') {
        if ($id) {
            $q = $pdo->prepare("
                SELECT id_cliente, nome, email, telefone, foto_url,
                       saldo_bonus, endereco, cidade, pais,
                       compras_realizadas, cliente_verificado,
                       google_account, senha_manual,
                       ativo, criado_em
                FROM clientes WHERE id_cliente = ?
            ");
            $q->execute([$id]);
            $c = $q->fetch(PDO::FETCH_ASSOC);
            echo json_encode(["success" => true, "data" => $c ?: null]);
        } else {
            $busca = $_GET['busca'] ?? '';
            if ($busca) {
                $q = $pdo->prepare("
                    SELECT id_cliente, nome, email, telefone, foto_url,
                           saldo_bonus, endereco, city as cidade, pais,
                           compras_realizadas, cliente_verificado,
                           google_account, senha_manual,
                           ativo, criado_em
                    FROM clientes
                    WHERE nome LIKE ? OR email LIKE ? OR telefone LIKE ?
                    ORDER BY criado_em DESC
                ");
                $like = "%$busca%";
                $q->execute([$like, $like, $like]);
            } else {
                $q = $pdo->query("
                    SELECT id_cliente, nome, email, telefone, foto_url,
                           saldo_bonus, endereco, cidade, pais,
                           compras_realizadas, cliente_verificado,
                           google_account, senha_manual,
                           ativo, criado_em
                    FROM clientes
                    ORDER BY criado_em DESC
                ");
            }
            $clientes = $q->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode([
                "success" => true,
                "data"    => $clientes,
                "total"   => count($clientes),
            ]);
        }
    }

    // ── POST — Criar Cliente ou Bloquear/Desbloquear ────────
    elseif ($method === 'POST') {
        $d = json_decode(file_get_contents("php://input"), true) ?? [];

        // Acção de bloquear/desbloquear via POST com campo action
        $acao = $d['acao'] ?? '';

        if ($acao === 'bloquear' || $acao === 'desbloquear') {
            $id_cliente = intval($d['id_cliente'] ?? 0);
            if (!$id_cliente) {
                echo json_encode(["success" => false, "message" => "ID em falta."]);
                exit;
            }
            $novoEstado = ($acao === 'desbloquear') ? 1 : 0;
            $pdo->prepare("UPDATE clientes SET ativo = ? WHERE id_cliente = ?")
                ->execute([$novoEstado, $id_cliente]);

            echo json_encode([
                "success" => true,
                "message" => $acao === 'bloquear'
                    ? "Conta bloqueada com sucesso."
                    : "Conta desbloqueada com sucesso.",
                "ativo"   => $novoEstado,
            ]);
            exit;
        }

        // Fluxo para criar um novo cliente manualmente pelo painel
        $q = $pdo->prepare("
            INSERT INTO clientes
              (nome, email, senha, telefone, endereco, cidade, pais, data_nascimento, ativo)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
        ");
        $q->execute([
            $d['nome']            ?? '',
            $d['email']           ?? '',
            password_hash($d['senha'] ?? '123456', PASSWORD_DEFAULT),
            $d['telefone']        ?? '',
            $d['endereco']        ?? '',
            $d['cidade']          ?? 'Luanda',
            $d['pais']            ?? 'Angola',
            $d['data_nascimento'] ?? null,
        ]);
        echo json_encode(["success" => true, "id" => $pdo->lastInsertId()]);
    }

    // ── PUT — Actualizar Dados do Cliente ───────────────────
    elseif ($method === 'PUT') {
        $d  = json_decode(file_get_contents("php://input"), true) ?? [];
        $id = intval($d['id_cliente'] ?? $id);

        if (!$id) {
            echo json_encode(["success" => false, "message" => "ID em falta."]);
            exit;
        }

        // Suporte alternativo a bloquear/desbloquear via PUT enviando o estado 'ativo'
        if (isset($d['ativo'])) {
            $pdo->prepare("UPDATE clientes SET ativo = ? WHERE id_cliente = ?")
                ->execute([intval($d['ativo']), $id]);
            echo json_encode([
                "success" => true,
                "message" => $d['ativo'] ? "Conta desbloqueada." : "Conta bloqueada.",
                "ativo"   => intval($d['ativo']),
            ]);
            exit;
        }

        $q = $pdo->prepare("
            UPDATE clientes
            SET nome = ?, email = ?, telefone = ?,
                endereco = ?, cidade = ?, cliente_verificado = ?
            WHERE id_cliente = ?
        ");
        $q->execute([
            $d['nome']               ?? '',
            $d['email']              ?? '',
            $d['telefone']           ?? '',
            $d['endereco']           ?? '',
            $d['cidade']             ?? '',
            $d['cliente_verificado'] ?? 0,
            $id,
        ]);
        echo json_encode(["success" => true, "message" => "Cliente actualizado com sucesso."]);
    }

    // ── DELETE — Eliminar Cliente do Sistema ────────────────
    elseif ($method === 'DELETE') {
        if (!$id) {
            echo json_encode(["success" => false, "message" => "ID em falta."]);
            exit;
        }
        $pdo->prepare("DELETE FROM clientes WHERE id_cliente = ?")
            ->execute([$id]);
        echo json_encode(["success" => true, "message" => "Cliente eliminado com sucesso."]);
    }

    else {
        echo json_encode(["success" => false, "message" => "Método não suportado."]);
    }

} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => "Erro na base de dados: " . $e->getMessage()]);
}
?>