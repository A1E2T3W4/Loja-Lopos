<?php
// Inclui a conexão de produção e as diretivas unificadas de CORS
require_once 'config.php';

// Garante que o retorno é interpretado estritamente como JSON
header("Content-Type: application/json; charset=UTF-8");

$data   = json_decode(file_get_contents("php://input"), true) ?? [];
$method = $_SERVER['REQUEST_METHOD'];

try {
    /* ════════════════════════════════════════════════════════════
        POST — Vinculação de QR Code e Atualização de Estado
    ════════════════════════════════════════════════════════════ */
    if ($method === 'POST') {
        
        if (empty($data['id_pedido']) || empty($data['qr_code'])) {
            echo json_encode(["success" => false, "message" => "O id_pedido e o qr_code são campos obrigatórios."]);
            exit;
        }

        $id_pedido = intval($data['id_pedido']);
        $qr_code   = trim($data['qr_code']);
        $status    = trim($data['status'] ?? 'pendente');

        // Iniciamos uma transação para garantir que o QR Code e os históricos atualizam juntos
        $pdo->beginTransaction();

        // 1. Atualiza o QR Code e o Estado na tabela principal de pedidos
        $stmt = $pdo->prepare("
            UPDATE pedidos
            SET qr_code = :qr_code,
                status  = :status
            WHERE id_pedido = :id_pedido
        ");
        $stmt->execute([
            ':id_pedido' => $id_pedido,
            ':qr_code'   => $qr_code,
            ':status'    => $status,
        ]);

        // 2. Sincroniza dinamicamente com a tabela 'historico_vendas' se esta existir
        if ($pdo->query("SHOW TABLES LIKE 'historico_vendas'")->fetch()) {
            $stmtHv = $pdo->prepare("
                UPDATE historico_vendas 
                SET status = :status 
                WHERE id_pedido = :id_pedido AND status != 'entregue'
            ");
            $stmtHv->execute([
                ':status'    => $status,
                ':id_pedido' => $id_pedido
            ]);
        }

        // 3. Sincroniza dinamicamente com a tabela 'historico_cliente' se esta existir
        if ($pdo->query("SHOW TABLES LIKE 'historico_cliente'")->fetch()) {
            $stmtHc = $pdo->prepare("
                UPDATE historico_cliente 
                SET status = :status 
                WHERE id_pedido = :id_pedido AND status != 'entregue'
            ");
            $stmtHc->execute([
                ':status'    => $status,
                ':id_pedido' => $id_pedido
            ]);
        }

        $pdo->commit();

        echo json_encode([
            "success" => true, 
            "message" => "QR Code vinculado e estado sincronizado com sucesso no LOPOS."
        ]);
        exit;

    } else {
        // Fallback seguro para verbos HTTP incorretos sem quebrar o cliente JSON
        echo json_encode([
            "success" => false, 
            "message" => "Método HTTP não suportado para esta operação de validação."
        ]);
        exit;
    }

} catch (Exception $e) {
    // Se a transação falhar, desfaz as alterações preventivamente
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    echo json_encode([
        "success" => false, 
        "message" => "Erro crítico ao processar o QR Code: " . $e->getMessage()
    ]);
    exit;
}
?>