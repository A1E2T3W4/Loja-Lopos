<?php
require_once 'config.php';

header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit(); }

$input  = json_decode(file_get_contents('php://input'), true) ?? [];
$action = $input['action'] ?? '';

/* ── 1. GERAR CÓDIGO DE CADASTRO ── */
if ($action === 'enviar') {
    $email = trim($input['email'] ?? '');

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(["success" => false, "message" => "E-mail inválido."]);
        exit();
    }

    // Prevenção de duplicação: Verifica se o e-mail já existe
    $stmt = $pdo->prepare("SELECT id_cliente, google_account FROM clientes WHERE email = ? LIMIT 1");
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        echo json_encode(["success" => false, "message" => "Este e-mail já possui uma conta registada."]);
        exit();
    }

    // Limpeza de códigos pendentes anteriores para este e-mail
    $pdo->prepare("DELETE FROM codigos_verificacao WHERE email = ? AND tipo = 'cadastro'")->execute([$email]);

    $codigo = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    $expira = date('Y-m-d H:i:s', strtotime('+15 minutes'));

    $pdo->prepare("INSERT INTO codigos_verificacao (email, codigo, tipo, usado, expira_em, criado_em) VALUES (?, ?, 'cadastro', 0, ?, NOW())")
        ->execute([$email, $codigo, $expira]);

    // NOTA: Se for manter o EmailJS no front-end, precisa do código. 
    // Para maior segurança, considere enviar o e-mail diretamente pelo servidor (via PHPMailer).
    echo json_encode([
        "success" => true,
        "codigo"  => $codigo, 
        "message" => "Código gerado com sucesso."
    ]);
    exit();
}

/* ── 2. CONFIRMAR CÓDIGO DE CADASTRO ── */
if ($action === 'confirmar') {
    $email  = trim($input['email'] ?? '');
    $codigo = trim($input['codigo'] ?? '');

    $stmt = $pdo->prepare("
        SELECT id FROM codigos_verificacao 
        WHERE email = ? AND codigo = ? AND tipo = 'cadastro' AND usado = 0 AND expira_em > NOW()
    ");
    $stmt->execute([$email, $codigo]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        echo json_encode(["success" => false, "message" => "Código inválido ou expirado."]);
        exit();
    }

    // Marca como usado para evitar reuso
    $pdo->prepare("UPDATE codigos_verificacao SET usado = 1 WHERE id = ?")->execute([$row['id']]);

    echo json_encode(["success" => true, "message" => "E-mail verificado. Pode prosseguir com o cadastro."]);
    exit();
}

echo json_encode(["success" => false, "message" => "Ação inválida."]);